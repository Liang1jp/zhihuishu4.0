"""Verify the 共享课 fix against a fixture shaped like the real course-list API.

The native mySpace page routes a course card by its fields: `courseType` 0/1
open this app's own singleCourse study pages, `courseType` 2 is 共享课 (a
different platform), any other value is the AI course entry, and a `newFlag`
of 0 sends the card to the AI page. A 共享课 used to be dropped from the list
entirely, which is what these checks pin down.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'script'))
import run  # noqa: E402

DATA = {
    'studyCourseList': [
        {'courseId': 111, 'classId': 1, 'courseName': '高等数学', 'courseType': 0, 'newFlag': True},
        {'courseId': 222, 'classId': 2, 'courseName': '共享通识课', 'courseType': 2, 'newFlag': True},
        {'courseId': 333, 'classId': 3, 'courseName': 'AI 课程', 'courseType': 5, 'newFlag': True},
        {'courseId': 444, 'classId': 4, 'courseName': '老平台课程', 'courseType': 0, 'newFlag': 0},
        {'courseId': 'abc', 'classId': 5, 'courseName': '脏数据', 'courseType': 0, 'newFlag': True},
    ],
    'completeCourseList': [
        {'courseId': 111, 'classId': 1, 'courseName': '高等数学', 'courseType': 1, 'newFlag': 1},
        {'courseId': 555, 'classId': 6, 'courseName': '已完成的共享课', 'courseType': 2, 'newFlag': None},
    ],
}


def main():
    courses = run.course_list(DATA)
    found = {c['course_id']: c for c in courses}
    print('listed :', sorted(found))
    print('kinds  :', {c['course_id']: c['kind'] for c in courses})
    print('counts :', run.course_breakdown(courses))

    assert set(found) == {'111', '222', '333', '555'}, f'listing mismatch: {set(found)}'
    assert found['111']['kind'] == '智慧课程', 'courseType 0/1 must be 智慧课程'
    assert found['222']['kind'] == '共享课', 'courseType 2 must be 共享课'
    assert found['333']['kind'] == 'AI课程', 'unknown courseType falls back to AI课程'
    assert found['555']['kind'] == '共享课', 'null newFlag must stay visible'
    assert len([c for c in courses if c['course_id'] == '111']) == 1, 'dupes must merge'
    assert not any(c['name'] == '老平台课程' for c in courses), 'newFlag 0 belongs to the AI page'
    assert not any(c['name'] == '脏数据' for c in courses), 'non-numeric ids must be skipped'

    # Only 智慧课程 may be driven by the singleCourse knowledge APIs.
    supported = [c for c in courses if c['kind'] == '智慧课程']
    assert [c['course_id'] for c in supported] == ['111']
    assert run.course_fields(courses)[1]['course_type'] == '2'
    print('\nOK: 共享课 is recognized, labelled, and kept out of unsupported work')


if __name__ == '__main__':
    main()
"""共享课（老平台）接口抓取 —— 只记录页面自己发出的请求。

用法（在项目根目录执行）：
    python script\\shared_trace.py
    python script\\shared_trace.py --url "<共享课页面网址>"

它用和刷课脚本相同的浏览器配置打开页面，把页面**自己**发出的
studyservice-api 请求（地址、方法、请求体、响应）写到
script/output/shared-trace-*.json。

全程只读：不调用任何保存接口，不改动学习记录。
"""
import argparse
import json
import re
import sys
import time
from datetime import datetime
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent
PROFILE = ROOT / '.session'
OUTPUT = ROOT / 'output'
SHARED_HOST = 'studyvideoh5.zhihuishu.com'
TARGET = 'studyservice-api.zhihuishu.com'
MAX_BODY = 20000
URL_HINT = ('https://studyvideoh5.zhihuishu.com/stuStudy'
            '?recruitAndCourseId=＜你自己的编号＞')

# 页面结构探测：为后续自动化找出「节次列表」在哪、<video> 怎么控制。
# 只读 DOM，不点击、不播放。
PROBE_JS = r"""(names) => {
    const result = {url: location.href, title: document.title,
                    videos: [], matches: [], globals: [], counts: {}};

    document.querySelectorAll('video').forEach((v, i) => {
        result.videos.push({
            i, duration: Number.isFinite(v.duration) ? Math.round(v.duration) : null,
            paused: v.paused, rate: v.playbackRate,
            currentSrc: (v.currentSrc || v.src || '').slice(0, 120),
            width: v.clientWidth, height: v.clientHeight,
        });
    });

    const classHits = new Set();
    document.querySelectorAll('[class]').forEach((el) => {
        const cls = typeof el.className === 'string' ? el.className : '';
        cls.split(/\s+/).filter(Boolean).forEach((token) => {
            if (/lesson|catalog|chapter|clearfix|video|node|item|list/i.test(token)) {
                classHits.add(token);
            }
        });
    });
    [...classHits].slice(0, 60).forEach((token) => {
        result.counts[token] = document.querySelectorAll('.' + CSS.escape(token)).length;
    });

    for (const name of names.slice(0, 10)) {
        const needle = String(name || '').trim().slice(0, 16);
        if (!needle) continue;
        for (const el of document.querySelectorAll('li, a, div, span, p')) {
            if (el.children.length > 2) continue;
            const text = (el.textContent || '').trim();
            if (!text || text.length > 80 || text.indexOf(needle) === -1) continue;
            const chain = [];
            let node = el;
            for (let depth = 0; depth < 5 && node && node.tagName; depth += 1) {
                const cls = typeof node.className === 'string'
                    ? node.className.split(/\s+/).filter(Boolean).slice(0, 4).join('.') : '';
                chain.push(node.tagName.toLowerCase() + (cls ? '.' + cls : ''));
                node = node.parentElement;
            }
            result.matches.push({name: String(name).slice(0, 40), text: text.slice(0, 50),
                                 chain, tag: el.tagName.toLowerCase()});
            break;
        }
    }

    for (const key of ['ablePlayerX', 'player', 'videojs', 'aiPlayer', 'vjsPlayer']) {
        if (typeof window[key] !== 'undefined') {
            result.globals.push({name: key, type: typeof window[key]});
        }
    }
    return result;
}"""


def save(path, payload):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    for attempt in range(3):
        try:
            temp.replace(path)
            return
        except PermissionError:
            if attempt == 2:
                raise
            time.sleep(0.2)


def strip_path(url):
    """把 .../gateway/t/v1/learning/videolist 收敛成 learning/videolist。"""
    parts = urlsplit(url)
    if '/gateway/t/' not in parts.path:
        return parts.path
    segments = parts.path.rsplit('/gateway/t/', 1)[-1].split('/')
    if segments and re.fullmatch(r'v\d+', segments[0]):
        segments = segments[1:]
    return '/'.join(segments)


def await_catalog(records):
    """从捕获到的 videolist 响应里抽出可播放的视频单元。

    一个「节」可能挂多个子视频（videoSmallLessons），上报进度是按子视频走的，
    所以这里统一展开成播放单元。
    """
    for record in records:
        if not record['path'].endswith('learning/videolist'):
            continue
        try:
            payload = json.loads(record['body'])
            data = payload.get('data') or {}
        except Exception:
            continue
        chapters = data.get('videoChapterDtos') or []
        units = []
        for chapter in chapters:
            for lesson in chapter.get('videoLessons') or []:
                smalls = lesson.get('videoSmallLessons') or []
                sources = smalls if smalls else [lesson]
                for item in sources:
                    units.append({
                        'chapterId': chapter.get('id'),
                        'chapter': chapter.get('name'),
                        'chapterPass': chapter.get('isPass'),
                        'lessonId': lesson.get('id'),
                        'lessonName': lesson.get('name'),
                        'id': item.get('id'),
                        'name': item.get('name'),
                        'videoId': item.get('videoId'),
                        'videoSec': item.get('videoSec'),
                        'studied': item.get('isStudiedLesson'),
                    })
        return {'chapterCount': len(chapters), 'lessons': units}
    return {'chapterCount': 0, 'lessons': []}


def attach(context, records):
    """记录每个 studyservice-api 请求的地址、请求体与响应。"""

    def on_response(response):
        url = response.url
        if TARGET not in url:
            return
        entry = {'url': url, 'path': strip_path(url),
                 'method': response.request.method}
        try:
            entry['post_data'] = response.request.post_data
        except Exception:
            entry['post_data'] = None
        entry['status'] = response.status
        try:
            body = response.text()
        except Exception as error:
            body = f'<unreadable: {type(error).__name__}>'
        entry['body'] = body[:MAX_BODY]
        records.append(entry)
        print(f'    [{len(records):02d}] {entry["status"]} {entry["path"]}  ({len(body)}b)',
              flush=True)

    context.on('response', on_response)


def main():
    parser = argparse.ArgumentParser(description='抓取共享课页面自己发出的接口请求')
    parser.add_argument('--url', default='', help='共享课页面网址（必填）')
    parser.add_argument('--channel', choices=('msedge', 'chrome', 'chromium'), default='msedge')
    parser.add_argument('--wait', type=int, default=15, help='首屏自动加载等待秒数')
    parser.add_argument('--auto', action='store_true', help='不等待回车，直接倒数后自动结束')
    parser.add_argument('--watch', type=int, default=30, help='--auto 模式下播放视频的等待秒数')
    args = parser.parse_args()

    args.url = (args.url or '').strip()
    if not args.url:
        print('喵?！(>﹏<) 还差共享课页面网址喵～\n'
              f'  形如：{URL_HINT}\n'
              '  在界面里点按钮时填一次，程序会记住喵。')
        return 2
    if SHARED_HOST not in args.url:
        print(f'喵…(ಥ_ಥ) 这个网址看起来不是共享课页面，需要 {SHARED_HOST} 开头的喵～')
        return 2

    OUTPUT.mkdir(parents=True, exist_ok=True)
    target = OUTPUT / (datetime.now().strftime('shared-trace-%Y%m%d-%H%M%S') + '.json')
    records = []

    from playwright.sync_api import sync_playwright

    print('喵(๑°3°๑) 正在打开共享课页面，这个窗口会自己发请求，本喵只旁观不动手喵～', flush=True)
    with sync_playwright() as playwright:
        options = {'headless': False, 'service_workers': 'block',
                   'viewport': {'width': 1440, 'height': 900},
                   'locale': 'zh-CN', 'timezone_id': 'Asia/Shanghai',
                   'ignore_default_args': ['--enable-automation'],
                   'args': ['--disable-blink-features=AutomationControlled']}
        if args.channel != 'chromium':
            options['channel'] = args.channel
        try:
            context = playwright.chromium.launch_persistent_context(str(PROFILE), **options)
            context.add_init_script(
                "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});"
                "if (!window.chrome) { window.chrome = {runtime: {}}; }")
        except Exception as error:
            print(f'喵…(ಥ_ಥ) 浏览器没打开：{type(error).__name__}\n'
                  '如果提示配置目录被占用，请先关掉刷课脚本开着的浏览器窗口再重试喵～')
            return 2

        try:
            attach(context, records)
            page = context.pages[0] if context.pages else context.new_page()
            page.goto(args.url, wait_until='domcontentloaded', timeout=60000)
            print(f'喵～页面已打开，等它自己加载课程数据（{args.wait} 秒）…', flush=True)
            page.wait_for_timeout(args.wait * 1000)

            print('\n喵(●—●) 接下来请在弹出窗口里做两件事：\n'
                  '  1. 点开左侧第一个视频，播放 10 秒左右\n'
                  '  2. 点暂停，或者切到下一节\n', flush=True)
            if args.auto:
                print(f'本喵会自己等 {args.watch} 秒，时间到了就自动收工喵～\n', flush=True)
                page.wait_for_timeout(args.watch * 1000)
            else:
                print('做完回到这个窗口按回车喵～\n', flush=True)
                try:
                    input('按回车继续...')
                except EOFError:
                    print('（没有输入，继续等待 30 秒）', flush=True)
                    page.wait_for_timeout(30000)
            page.wait_for_timeout(3000)

            # 顺便把页面结构也探一遍，省得让你再跑一次。
            probe = None
            try:
                catalog = await_catalog(records)
                names = [lesson.get('name') for lesson in catalog['lessons']]
                probe = page.evaluate(PROBE_JS, [name or '' for name in names])
                print(f"\n喵～顺带探测到 {len(catalog['lessons'])} 节课程、"
                      f"{len(probe.get('videos') or [])} 个视频元素", flush=True)
            except Exception as error:
                print(f'喵…结构探测没成功（{type(error).__name__}），但请求记录还在', flush=True)

            result = {'url': args.url, 'started_at': datetime.now().isoformat(),
                      'records': records,
                      'catalog': None,
                      'probe': probe,
                      'hint': [r['path'] for r in records]}
            try:
                result['catalog'] = await_catalog(records)
            except Exception:
                pass
            save(target, result)
            print(f'\n喵(●—●) 共记录 {len(records)} 条接口请求，已保存到：\n  {target}', flush=True)
            print('把这个文件发给本喵，本喵就能照着写共享课的客户端啦～', flush=True)
            if not records:
                print('\n喵…(ಥ_ಥ) 一条都没记录到。可能是页面没加载完，'
                      '或者这个页面不是共享课播放页喵～', flush=True)
        finally:
            context.close()
    return 0


if __name__ == '__main__':
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, 'reconfigure'):
            stream.reconfigure(encoding='utf-8', errors='replace')
    sys.exit(main())

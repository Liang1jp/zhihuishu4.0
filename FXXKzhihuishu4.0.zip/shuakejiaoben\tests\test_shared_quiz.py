"""Verify quiz parsing with fixtures covering both server shapes.

Real captures showed two cases:
  * zAnswer filled in  -> the question had been answered before
  * zAnswer null       -> only the option flag (result == "1") hints the answer
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'script'))
import shared_learn  # noqa: E402


def payload(answer_id=None, flags=('1', '0')):
    return {
        'code': 0,
        'data': {'lessonTestQuestionUseInterfaceDtos': [{
            'testQuestion': {
                'name': '<div>天空看上去是蓝色的。</div>',
                'questionId': 1,
                'questionOptions': [
                    {'id': 11, 'content': '对', 'sort': 1, 'result': flags[0]},
                    {'id': 12, 'content': '错', 'sort': 2, 'result': flags[1]},
                ],
                'questionType': {'id': 1, 'name': '判断题', 'inputType': 'radio'},
            },
            'zAnswer': ({'id': None, 'answer': str(answer_id), 'isDelete': 0}
                        if answer_id is not None else None),
        }]},
    }


def main():
    # 1) A plain "温馨提示 / 我知道了" popup carries no lessonPopupExam data,
    #    so it must never be treated as a quiz -- that was the bug that made the
    #    engine skip whole lessons.
    assert shared_learn.quiz_ready({'quiz': None, 'last_quiz': 0}) is None
    assert shared_learn.quiz_ready({}) is None
    assert shared_learn.quiz_ready({'quiz': {'data': {}}, 'last_quiz': 1e12}) is None

    # 2) Stale quiz data must not leak into the next lesson.
    fresh = {'quiz': payload(answer_id=None), 'last_quiz': 1000.0}
    assert shared_learn.quiz_ready(fresh, now=1010.0) is not None, 'fresh quiz expected'
    assert shared_learn.quiz_ready(fresh, now=1400.0) is None, 'stale quiz must be ignored'
    print('quiz_ready: fresh/stale handled')

    # 3) Case: server already knows the answer.
    known = shared_learn.extract_quiz(payload(answer_id=11))
    print('with zAnswer   :', known['known'])
    assert known['known'] == {'id': 11, 'text': '对', 'source': 'zAnswer'}

    # Case 2: the usual case — only the option flag is available.
    unknown = shared_learn.extract_quiz(payload(answer_id=None))
    print('without zAnswer:', unknown['known'])
    assert unknown['known'] == {'id': 11, 'text': '对', 'source': 'option-flag'}

    # Case 3: ambiguous flags must not be guessed blindly.
    ambiguous = shared_learn.extract_quiz(payload(answer_id=None, flags=('1', '1')))
    print('ambiguous flags:', ambiguous['known'])
    assert ambiguous['known'] is None, 'two correct-looking options must fall through to AI'

    # Malformed payloads must be tolerated.
    assert shared_learn.extract_quiz(None) is None
    assert shared_learn.extract_quiz({'data': {}}) is None
    assert shared_learn.extract_quiz({'data': {'lessonTestQuestionUseInterfaceDtos': [
        {'testQuestion': {'questionOptions': []}}]}}) is None

    # The chosen text must always be one of the offered options.
    for case in (known, unknown):
        texts = {o['content'] for o in case['options']}
        assert case['known']['text'] in texts
        print('question:', case['question'][:40], '| options:', texts)
    print('\nOK: quiz parsing covers zAnswer, option flag and ambiguous cases')


if __name__ == '__main__':
    main()
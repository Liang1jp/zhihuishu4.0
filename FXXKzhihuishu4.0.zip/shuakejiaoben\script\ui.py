"""智慧树小助手 UI（Tkinter）。

- 列出智慧课程 + 翻转课，逐门勾选“刷课 / 测验作业”
- DeepSeek API 设置存 script/config.json
- AI 先出答案，界面确认后才提交
"""
import json
import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, scrolledtext, simpledialog, ttk

import ai

HERE = Path(__file__).resolve().parent
PYTHON = sys.executable
NO_WINDOW = 0x08000000 if sys.platform == 'win32' else 0

CHECK = '☑'
UNCHECK = '☐'


class Job:
    def __init__(self, args, sink):
        self.args = args
        self.sink = sink
        self.queue = queue.Queue()
        env = dict(os.environ)
        env['PYTHONUTF8'] = '1'
        env['PYTHONIOENCODING'] = 'utf-8'
        self.proc = subprocess.Popen(
            [PYTHON, *args], cwd=str(HERE), env=env,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.PIPE,
            text=True, encoding='utf-8', errors='replace', bufsize=1,
            creationflags=NO_WINDOW)
        self.thread = threading.Thread(target=self._read, daemon=True)
        self.thread.start()

    def _read(self):
        try:
            for line in self.proc.stdout:
                self.queue.put(line.rstrip('\r\n'))
        finally:
            self.queue.put(None)

    def send(self, payload):
        if self.proc.stdin:
            try:
                self.proc.stdin.write(json.dumps(payload, ensure_ascii=False) + '\n')
                self.proc.stdin.flush()
            except Exception as error:
                self.sink(f'发送失败：{error}')

    def stop(self):
        try:
            self.proc.terminate()
        except Exception:
            pass


class App:
    def __init__(self, root):
        self.root = root
        self.root.title('智慧树小助手')
        self.root.geometry('1080x760')
        self.jobs = []
        self.current = None
        self.pending = []
        self.answer_queue = []
        self.courses = {}
        self.homeworks = {}
        config = ai.load_config()
        self.var_key = tk.StringVar(value=config.get('deepseek_api_key', ''))
        self.var_base = tk.StringVar(value=config.get('base_url', ai.DEFAULT_BASE))
        self.var_model = tk.StringVar(value=config.get('model', ai.DEFAULT_MODEL))
        self.status = tk.StringVar(value='就绪')
        self._build()
        self.root.after(120, self.poll)

    # ---------- UI ----------
    def _build(self):
        top = ttk.LabelFrame(self.root, text='DeepSeek 官方 API')
        top.pack(fill='x', padx=8, pady=6)
        ttk.Label(top, text='API Key').grid(row=0, column=0, padx=4, pady=4)
        ttk.Entry(top, textvariable=self.var_key, width=44, show='*').grid(row=0, column=1, padx=4)
        ttk.Button(top, text='保存', command=self.save_config).grid(row=0, column=2, padx=4)
        ttk.Button(top, text='测试', command=self.test_api).grid(row=0, column=3, padx=4)
        ttk.Label(top, text='Base URL').grid(row=1, column=0, padx=4)
        ttk.Entry(top, textvariable=self.var_base, width=44).grid(row=1, column=1, padx=4, pady=2)
        ttk.Label(top, text='模型').grid(row=1, column=2, padx=4)
        ttk.Entry(top, textvariable=self.var_model, width=18).grid(row=1, column=3, padx=4)

        bar = ttk.Frame(self.root)
        bar.pack(fill='x', padx=8)
        ttk.Button(bar, text='读取课程', command=self.load_courses).pack(side='left', padx=3)
        ttk.Button(bar, text='课程核对', command=self.load_courses_dump).pack(side='left', padx=3)
        ttk.Button(bar, text='全选刷课', command=lambda: self.set_all(True)).pack(side='left', padx=3)
        ttk.Button(bar, text='全不选', command=lambda: self.set_all(False)).pack(side='left', padx=3)
        ttk.Button(bar, text='开始刷课', command=self.start_brush).pack(side='left', padx=3)
        ttk.Button(bar, text='读取作业/测验', command=self.load_homework).pack(side='left', padx=3)
        ttk.Button(bar, text='AI 答题（选中）', command=self.start_answer).pack(side='left', padx=3)
        ttk.Button(bar, text='停止', command=self.stop_current).pack(side='left', padx=3)

        shared_bar = ttk.Frame(self.root)
        shared_bar.pack(fill='x', padx=8, pady=(4, 0))
        ttk.Label(shared_bar, text='共享课（老平台）：').pack(side='left', padx=(0, 2))
        ttk.Button(shared_bar, text='① 识别我的共享课',
                   command=self.discover_shared).pack(side='left', padx=3)
        ttk.Button(shared_bar, text='② 选择要刷的课',
                   command=self.pick_shared).pack(side='left', padx=3)
        ttk.Button(shared_bar, text='③ 开始刷',
                   command=self.learn_shared).pack(side='left', padx=3)
        ttk.Button(shared_bar, text='抓接口（调试）',
                   command=self.trace_shared).pack(side='left', padx=3)

        course_box = ttk.LabelFrame(self.root, text='课程（点击“刷课 / 测验作业”列切换）')
        course_box.pack(fill='both', expand=False, padx=8, pady=6)
        columns = ('source', 'name', 'brush', 'work')
        self.course_tree = ttk.Treeview(course_box, columns=columns, show='headings', height=8)
        for key, text, width in (('source', '来源', 100), ('name', '课程', 520),
                                 ('brush', '刷课', 80), ('work', '测验作业', 90)):
            self.course_tree.heading(key, text=text)
            self.course_tree.column(key, width=width, anchor='center' if key != 'name' else 'w')
        self.course_tree.pack(fill='x', padx=4, pady=4)
        self.course_tree.bind('<Button-1>', self.toggle_course)

        hw_box = ttk.LabelFrame(self.root, text='作业 / 测验（勾选要 AI 处理的条目）')
        hw_box.pack(fill='both', expand=False, padx=8, pady=6)
        hw_columns = ('course', 'title', 'status', 'select')
        self.hw_tree = ttk.Treeview(hw_box, columns=hw_columns, show='headings', height=8)
        for key, text, width in (('course', '课程', 240), ('title', '标题', 420),
                                 ('status', '状态', 100), ('select', '选择', 80)):
            self.hw_tree.heading(key, text=text)
            self.hw_tree.column(key, width=width, anchor='center' if key != 'title' else 'w')
        self.hw_tree.pack(fill='x', padx=4, pady=4)
        self.hw_tree.bind('<Button-1>', self.toggle_homework)

        log_box = ttk.LabelFrame(self.root, text='日志')
        log_box.pack(fill='both', expand=True, padx=8, pady=6)
        self.log_text = scrolledtext.ScrolledText(log_box, height=14, state='disabled')
        self.log_text.pack(fill='both', expand=True, padx=4, pady=4)
        ttk.Label(self.root, textvariable=self.status, anchor='w').pack(fill='x', padx=10, pady=(0, 6))

    def log(self, text):
        self.log_text.configure(state='normal')
        self.log_text.insert('end', str(text) + '\n')
        self.log_text.see('end')
        self.log_text.configure(state='disabled')

    # ---------- 配置 ----------
    def save_config(self):
        ai.save_config({'deepseek_api_key': self.var_key.get().strip(),
                        'base_url': self.var_base.get().strip(),
                        'model': self.var_model.get().strip()})
        self.log('DeepSeek 配置已保存到 script/config.json（打包发送前记得删掉）')

    def test_api(self):
        self.save_config()
        def run():
            try:
                client = ai.DeepSeek(self.var_key.get(), self.var_base.get(), self.var_model.get())
                self.root.after(0, self.log, 'DeepSeek 测试：' + str(client.test()).strip())
            except ai.AiError as error:
                self.root.after(0, self.log, f'DeepSeek 测试失败：{error}')
        threading.Thread(target=run, daemon=True).start()

    # ---------- 作业进程 ----------
    def start(self, args, interactive=False):
        job = Job(args, self.log)
        self.jobs.append(job)
        self.current = job
        self.status.set('运行中：' + ' '.join(args))
        self.log('> ' + ' '.join(args))
        return job

    def stop_current(self):
        if self.current:
            self.current.stop()
            self.log('已请求停止')
        self.pending = []
        self.answer_queue = []

    def poll(self):
        for job in list(self.jobs):
            finished = False
            while True:
                try:
                    line = job.queue.get_nowait()
                except queue.Empty:
                    break
                if line is None:
                    finished = True
                    break
                self.handle_line(job, line)
            if finished:
                self.jobs.remove(job)
                if job is self.current:
                    self.current = None
                    self.status.set('就绪')
                    if self.pending:
                        self.start(self.pending.pop(0))
                    elif self.answer_queue:
                        self.start_answer_next()
                try:
                    job.proc.wait(timeout=1)
                except Exception:
                    pass
        self.root.after(120, self.poll)

    def handle_line(self, job, line):
        text = line.strip()
        if not text:
            return
        if not text.startswith('{'):
            self.log(text)
            return
        try:
            data = json.loads(text)
        except Exception:
            self.log(text)
            return
        event = data.get('event')
        if event == 'log':
            self.log(data.get('text', ''))
        elif event == 'courses':
            self.fill_courses(data)
        elif event == 'homework':
            self.fill_homework(data)
        elif event == 'questions':
            self.on_questions(job, data)
        elif event == 'await':
            pass
        elif event == 'submitted':
            self.log('提交完成：' + str(data.get('message')))
        elif event == 'skipped':
            self.log('已跳过：' + str(data.get('message')))
        elif event == 'error':
            self.log('出错：' + str(data.get('message')))

    # ---------- 课程表 ----------
    def fill_courses(self, data):
        self.course_tree.delete(*self.course_tree.get_children())
        self.courses.clear()
        for item in data.get('smart') or []:
            iid = 'smart:' + item['id']
            kind = item.get('kind') or '智慧课程'
            self.courses[iid] = {'source': 'smart', 'id': item['id'],
                                 'class_id': item.get('class_id'), 'name': item['name'],
                                 'kind': kind, 'brush': False, 'work': False}
            self.course_tree.insert('', 'end', iid=iid, values=(
                kind, item['name'], UNCHECK, UNCHECK))
        for item in data.get('flip') or []:
            iid = 'flip:' + item['id']
            self.courses[iid] = {'source': 'flip', 'id': item['id'],
                                 'name': item['name'], 'brush': False, 'work': False}
            self.course_tree.insert('', 'end', iid=iid, values=(
                '翻转课', item['name'], UNCHECK, UNCHECK))
        smart = data.get('smart') or []
        counts = {}
        for item in smart:
            kind = item.get('kind') or '智慧课程'
            counts[kind] = counts.get(kind, 0) + 1
        summary = '、'.join(f'{kind} {count} 门' for kind, count in counts.items()) or '0 门'
        self.log(f"课程：{summary}，翻转课 {len(data.get('flip') or [])} 门")

    def toggle_course(self, event):
        if self.course_tree.identify('region', event.x, event.y) != 'cell':
            return
        iid = self.course_tree.identify_row(event.y)
        column = self.course_tree.identify_column(event.x)
        if not iid or column not in ('#3', '#4'):
            return
        item = self.courses.get(iid)
        if not item:
            return
        key = 'brush' if column == '#3' else 'work'
        if key == 'brush' and item.get('kind') not in (None, '智慧课程'):
            self.log(f"{item['name']} 是{item['kind']}，不在本脚本处理的智慧课程接口里，"
                     f'勾了也不会刷，先不勾喵～')
            return
        item[key] = not item[key]
        values = list(self.course_tree.item(iid, 'values'))
        values[2] = CHECK if item['brush'] else UNCHECK
        values[3] = CHECK if item['work'] else UNCHECK
        self.course_tree.item(iid, values=values)

    def set_all(self, value):
        for iid, item in self.courses.items():
            if value and item.get('kind') not in (None, '智慧课程'):
                continue  # 共享课 / AI 课程不走智慧课程接口
            item['brush'] = value
            values = list(self.course_tree.item(iid, 'values'))
            values[2] = CHECK if value else UNCHECK
            self.course_tree.item(iid, values=values)

    # ---------- 作业表 ----------
    def fill_homework(self, data):
        course = next((c for c in self.courses.values() if c['id'] == data.get('course_id')), None)
        course_name = course['name'] if course else data.get('course_id')
        for item in data.get('items') or []:
            status = item.get('status')
            label = {1: '未做', 3: '待批阅', 4: '已批阅'}.get(status, str(status))
            iid = f"{data.get('course_id')}:{item['homework_id']}"
            selectable = status == 1
            self.homeworks[iid] = {'course_id': data.get('course_id'), 'title': item['title'],
                                   'homework_id': item['homework_id'], 'status': status,
                                   'selected': False, 'selectable': selectable}
            self.hw_tree.insert('', 'end', iid=iid, values=(
                course_name, item['title'], label, CHECK if False else UNCHECK))
        self.log(f"作业/测验：{course_name} 共 {len(data.get('items') or [])} 条")

    def toggle_homework(self, event):
        if self.hw_tree.identify('region', event.x, event.y) != 'cell':
            return
        iid = self.hw_tree.identify_row(event.y)
        column = self.hw_tree.identify_column(event.x)
        if not iid or column != '#4':
            return
        item = self.homeworks.get(iid)
        if not item or not item['selectable']:
            return
        item['selected'] = not item['selected']
        values = list(self.hw_tree.item(iid, 'values'))
        values[3] = CHECK if item['selected'] else UNCHECK
        self.hw_tree.item(iid, values=values)

    # ---------- 动作 ----------
    def load_courses(self):
        if self.current:
            self.log('已有任务在跑，先等它结束')
            return
        self.start([str(HERE / 'worker.py'), 'list', '--show', '--timeout', '600'])

    def load_courses_dump(self):
        """列课程并输出每门课的 courseType/分类，用来核对没识别到的课。"""
        if self.current:
            self.log('已有任务在跑，先等它结束')
            return
        self.start([str(HERE / 'worker.py'), 'list', '--show', '--dump', '--timeout', '600'])

    # ---------- 共享课（老平台） ----------
    def discover_shared(self):
        """打开学生首页，识别这个账号有哪些共享课。"""
        if self.current:
            self.log('已有任务在跑，先等它结束')
            return
        self.log('正在打开学生首页识别共享课，约 45 秒，别关窗口…')
        self.start([str(HERE / 'shared_courses.py'), '--wait', '45'])

    def latest_shared_courses(self):
        """读最近一次识别结果。"""
        folder = HERE / 'output'
        files = sorted(folder.glob('shared-courses-*.json'))
        if not files:
            return None, None
        path = files[-1]
        try:
            return path, json.loads(path.read_text(encoding='utf-8'))
        except Exception as error:
            self.log(f'读识别结果失败：{error}')
            return path, None

    def pick_shared(self):
        """从识别结果里勾选要刷的课，存进配置。"""
        path, data = self.latest_shared_courses()
        if not data:
            self.log('还没有识别结果，先点「① 识别我的共享课」')
            messagebox.showinfo('还没有清单', '先点「① 识别我的共享课」，等它列出来再选。')
            return
        courses = [c for c in (data.get('courses') or []) if c.get('url')]
        if not courses:
            self.log('识别结果里没有可刷的课（缺 recruitId 拼不出网址）')
            messagebox.showwarning('没有可选的课',
                                   '这次没识别到能拼出网址的课程，可能需要重新识别。')
            return

        current = ai.load_config().get('shared_urls') or []
        picked = self._choose_courses(courses, current)
        if picked is None:
            return
        ai.save_config({'shared_urls': picked})
        self.log(f'已选 {len(picked)} 门共享课，点「③ 开始刷」开始')
        if not picked:
            self.log('（没勾任何课，下次刷课会提示你重新选）')

    def _choose_courses(self, courses, selected):
        """多选对话框。返回选中的网址列表，取消返回 None。"""
        window = tk.Toplevel(self.root)
        window.title('选择要刷的共享课')
        window.transient(self.root)
        window.grab_set()
        ttk.Label(window, text='勾选要处理的课（可多选）：').pack(anchor='w', padx=14, pady=(14, 6))
        frame = ttk.Frame(window)
        frame.pack(fill='both', expand=True, padx=14)
        rows = []
        for course in courses:
            var = tk.BooleanVar(value=course['url'] in selected)
            label = f"{course['courseName']}   （courseId {course['courseId']}）"
            ttk.Checkbutton(frame, text=label, variable=var).pack(anchor='w', pady=2)
            rows.append((var, course))
        answer = {'value': None}

        def confirm():
            answer['value'] = [c['url'] for v, c in rows if v.get()]
            window.destroy()

        def cancel():
            window.destroy()

        bar = ttk.Frame(window)
        bar.pack(fill='x', padx=14, pady=14)
        ttk.Button(bar, text='确定', command=confirm).pack(side='right', padx=4)
        ttk.Button(bar, text='取消', command=cancel).pack(side='right')
        window.wait_window()
        return answer['value']

    def shared_urls(self):
        """取要刷的共享课网址列表。"""
        urls = ai.load_config().get('shared_urls') or []
        urls = [u for u in urls if isinstance(u, str) and u.strip()]
        if urls:
            return urls
        if messagebox.askyesno(
                '还没选课',
                '还没选择要刷的共享课。\n\n要先点「① 识别我的共享课」来列出你的课吗？'):
            self.discover_shared()
        return []

    def shared_url(self):
        """单课网址（抓接口调试用）：优先用已选的第一门。"""
        urls = self.shared_urls()
        if urls:
            return urls[0]
        url = (ai.load_config().get('shared_url') or '').strip()
        if url:
            return url
        url = simpledialog.askstring(
            '共享课网址',
            '请粘贴一门共享课的学习页面网址。\n'
            '（浏览器地址栏里 studyvideoh5.zhihuishu.com/stuStudy?... 开头的那个）',
            parent=self.root)
        url = (url or '').strip()
        if not url:
            self.log('没有填共享课网址，已取消')
            return ''
        if 'studyvideoh5.zhihuishu.com' not in url:
            messagebox.showwarning('网址不对',
                                   '这个不是共享课页面，需要 studyvideoh5.zhihuishu.com 开头的网址')
            return ''
        ai.save_config({'shared_url': url})
        return url

    def trace_shared(self):
        """打开共享课页面，记录页面自己发出的接口请求 + 页面结构（只读）。"""
        if self.current:
            self.log('已有任务在跑，先等它结束')
            return
        url = self.shared_url()
        if not url:
            return
        self.log('正在打开共享课页面：请在弹窗里点开视频播 10 秒左右，'
                 '30 秒后自动结束（会同时记录课程目录和页面结构）')
        self.start([str(HERE / 'shared_trace.py'), '--url', url, '--auto', '--watch', '30'])

    def learn_shared(self):
        """刷共享课：2 倍速驱动页面播放，由页面自己上报（服务端确认才算完成）。"""
        if self.current:
            self.log('已有任务在跑，先等它结束')
            return
        urls = self.shared_urls()
        if not urls:
            return
        mode = messagebox.askyesnocancel(
            '刷共享课',
            f'已选 {len(urls)} 门课。要怎么做？\n\n'
            '「是」= 每门只试跑 1 节（先确认能不能用）\n'
            '「否」= 跑完全部未完成（可能好几小时）\n'
            '「取消」= 什么都不做\n\n'
            '注意：这是真的在播放课程，会改变你的学习记录。')
        if mode is None:
            return
        args = [str(HERE / 'shared_learn.py')]
        for url in urls:
            args += ['--url', url]
        if mode:
            args += ['--limit', '1']
            self.log(f'共享课：{len(urls)} 门课各试跑 1 节。浏览器会打开页面并自动播放，别关窗口')
        else:
            self.log(f'共享课：跑完 {len(urls)} 门课的全部未完成。'
                     '这一步可能要几小时，期间别关窗口')
        self.start(args)

    def start_brush(self):
        if self.current:
            self.log('已有任务在跑')
            return
        smart = [c['id'] for c in self.courses.values() if c['brush'] and c['source'] == 'smart']
        flip = [c['id'] for c in self.courses.values() if c['brush'] and c['source'] == 'flip']
        args = [str(HERE / 'run.py')]
        if smart:
            for cid in smart:
                args += ['--course', cid]
        else:
            args += ['--no-smart']
        if flip:
            for cid in flip:
                args += ['--flip-course', cid]
        else:
            args += ['--no-flip']
        self.start(args)

    def load_homework(self):
        if self.current:
            self.log('已有任务在跑')
            return
        courses = [c['id'] for c in self.courses.values() if c['work']]
        if not courses:
            self.log('先在课程表里勾选“测验作业”列')
            return
        self.hw_tree.delete(*self.hw_tree.get_children())
        self.homeworks.clear()
        self.pending = [[str(HERE / 'worker.py'), 'homework', '--course', cid] for cid in courses]
        self.start(self.pending.pop(0))

    def start_answer(self):
        if self.current:
            self.log('已有任务在跑')
            return
        selected = [h for h in self.homeworks.values() if h['selected']]
        if not selected:
            self.log('先在作业表里勾选要处理的条目')
            return
        self.answer_queue = selected
        self.start_answer_next()

    def start_answer_next(self):
        if not self.answer_queue:
            return
        item = self.answer_queue.pop(0)
        self.log(f"处理：{item['title']}")
        self.start([str(HERE / 'worker.py'), 'answer',
                    '--course', item['course_id'],
                    '--homework', item['homework_id'],
                    '--title', item['title']], interactive=True)

    def on_questions(self, job, data):
        self.log(f"抓到 {len(data['questions'])} 道题，正在问 DeepSeek…")
        questions = data['questions']
        course = next((c for c in self.courses.values() if c['id'] == data.get('course_id')), {})
        prompt = [{'id': str(q['index']), 'type': q['title'], 'stem': q['content'],
                   'options': [{'letter': o['letter'], 'text': o['text']} for o in q['options']]}
                  for q in questions]

        def run():
            try:
                client = ai.DeepSeek(self.var_key.get(), self.var_base.get(), self.var_model.get())
                answers = client.answer_questions(prompt, course.get('name', ''))
            except ai.AiError as error:
                self.root.after(0, self.log, f'AI 失败：{error}')
                self.root.after(0, lambda: job.send({'action': 'skip'}))
                return
            self.root.after(0, self.show_review, job, questions, answers)

        threading.Thread(target=run, daemon=True).start()

    def show_review(self, job, questions, answers):
        mapping = {}
        for item in answers:
            try:
                mapping[int(item.get('id', -1))] = item
            except Exception:
                continue
        window = tk.Toplevel(self.root)
        window.title('AI 答案确认（确认后才会提交）')
        window.geometry('900x520')
        tree = ttk.Treeview(window, columns=('no', 'stem', 'answer', 'conf', 'reason'),
                            show='headings')
        for key, text, width in (('no', '题号', 50), ('stem', '题目', 380),
                                 ('answer', 'AI 答案', 90), ('conf', '把握', 60),
                                 ('reason', '理由', 300)):
            tree.heading(key, text=text)
            tree.column(key, width=width, anchor='w')
        tree.pack(fill='both', expand=True, padx=6, pady=6)
        source = []
        for question in questions:
            answer = mapping.get(question['index'], {})
            letter = str(answer.get('answer', '')).strip()
            options = {o['letter'].rstrip('.').upper(): o['text'] for o in question['options']}
            shown = letter if not options else f"{letter} — {options.get(letter.upper(), '?')}"
            tree.insert('', 'end', values=(question['index'] + 1, question['content'],
                                           shown, answer.get('confidence', ''),
                                           str(answer.get('reason', ''))[:120]))
            source.append({'index': question['index'], 'letter': letter})
        tip = ttk.Label(window, text='确认无误后点“确认提交”；点“取消”则不提交。')
        tip.pack(pady=(0, 4))
        buttons = ttk.Frame(window)
        buttons.pack(pady=(0, 10))

        def confirm():
            missing = [s for s in source if not s['letter']]
            if missing:
                messagebox.showwarning('有题没答案', f"还有 {len(missing)} 题没有答案，已按空处理")
            job.send({'action': 'submit', 'answers': source})
            self.log('已把确认后的答案交给浏览器提交')
            window.destroy()

        def cancel():
            job.send({'action': 'skip'})
            self.log('已取消提交')
            window.destroy()

        ttk.Button(buttons, text='确认提交', command=confirm).pack(side='left', padx=8)
        ttk.Button(buttons, text='取消', command=cancel).pack(side='left', padx=8)


def main():
    root = tk.Tk()
    try:
        ttk.Style().theme_use('vista')
    except Exception:
        pass
    App(root)
    root.mainloop()


if __name__ == '__main__':
    main()
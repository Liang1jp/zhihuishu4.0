"""Verify course discovery: id encoding, JSON harvesting, url parsing."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'script'))
import shared_courses  # noqa: E402
import shared_learn  # noqa: E402


def decode_course_id(token):
    """测试用的逆运算：把 token 解回 'recruitId;courseId'。"""
    key = shared_courses.ENCODE_KEY
    text = ''
    for index in range(0, len(token), 2):
        code = int(token[index:index + 2], 16) ^ ord(key[(index // 2) % len(key)])
        text += chr(code)
    return text


def main():
    # 1) The encoder must be deterministic and reversible.
    known = [
        (('1001', '2002'), '4b5859594e5b435847'),
        (('1003', '2004'), '4b58595b4e5b435841'),
    ]
    for (recruit, course), expected in known:
        got = shared_courses.encode_course_id(recruit, course)
        print(f'encode({recruit}, {course}) = {got}')
        assert got == expected, f'mismatch for {recruit}/{course}'
        assert decode_course_id(got) == f'{recruit};{course}', 'encoder must round-trip'
        # Digits and ';' XOR to ASCII, so every byte stays two hex chars.
        assert len(got) == 2 * len(f'{recruit};{course}')
    print('encoder: OK')

    # 2) Harvest must find courses nested anywhere in the payload.
    payload = {
        'code': 0,
        'data': {
            'studyCourseList': [
                {'courseId': 111, 'courseName': '课程甲', 'recruitId': 900, 'isShareCourse': 1},
                {'courseId': 222, 'courseName': '课程乙'},          # no recruitId yet
            ],
            'nested': {'deeper': [{'courseId': '333', 'name': '课程丙', 'recruitId': '901'}]},
        },
    }
    found = []
    shared_courses.harvest(payload, found)
    print('harvested:', [(c['courseId'], c['courseName'], c['recruitId']) for c in found])
    assert len(found) == 3
    rows = shared_courses.dedupe(found)
    assert {r['courseId'] for r in rows} == {'111', '222', '333'}
    # A course seen both with and without recruitId keeps only the usable row.
    merged = shared_courses.dedupe([
        {'courseId': '1', 'courseName': 'x', 'recruitId': ''},
        {'courseId': '1', 'courseName': 'x', 'recruitId': '77'},
    ])
    assert len(merged) == 1 and merged[0]['recruitId'] == '77', merged

    # Same course, different semesters -> both kept.
    two_terms = shared_courses.dedupe([
        {'courseId': '1', 'courseName': 'x', 'recruitId': '77'},
        {'courseId': '1', 'courseName': 'x', 'recruitId': '88'},
    ])
    assert len(two_terms) == 2, two_terms
    print('harvest + dedupe: OK')

    # 3) Malformed payloads must not raise.
    empty = []
    shared_courses.harvest(None, empty)
    shared_courses.harvest({'data': [1, 'x', None]}, empty)
    assert empty == []
    print('malformed payload: OK')

    # 4) Multi-url parsing: newlines, commas, duplicates, whitespace.
    urls = shared_learn.parse_urls([
        'https://studyvideoh5.zhihuishu.com/stuStudy?recruitAndCourseId=aa\n'
        'https://studyvideoh5.zhihuishu.com/stuStudy?recruitAndCourseId=bb',
        ' https://studyvideoh5.zhihuishu.com/stuStudy?recruitAndCourseId=cc , '
        'https://studyvideoh5.zhihuishu.com/stuStudy?recruitAndCourseId=aa ',
    ])
    print('parsed urls:', len(urls))
    assert len(urls) == 3, urls
    assert urls[0].endswith('aa') and urls[2].endswith('cc')
    assert shared_learn.parse_urls([]) == []
    assert shared_learn.parse_urls(['', '  ']) == []
    print('parse_urls: OK')

    print('\nOK: discovery helpers behave correctly')


if __name__ == '__main__':
    main()
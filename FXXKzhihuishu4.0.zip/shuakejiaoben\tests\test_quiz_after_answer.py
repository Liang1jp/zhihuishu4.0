"""Verify QUIZ_DOM_JS filtering: the "正确答案：B" suffix must not leak into options.

The real page appends 「正确 / 正确答案：B」 after answering, and an earlier
version swallowed it into option B's text, so clicking never matched.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'script'))
import shared_learn  # noqa: E402

# 与 QUIZ_DOM_JS 中一致的两步：先去掉答题后追加的内容，再匹配
STRIP_ANSWER = re.compile(r'正确答案\s*[:：]\s*[A-F]?')
HEAD = re.compile(r'【([^】]{1,8}题)】\s*([\s\S]{4,400}?)(?=\s*[A-F][.、]|$)')
OPT = re.compile(r'([A-F])[.、]\s*([\s\S]{1,60}?)(?=\s*[A-F][.、]|\s*提交|\s*关闭|\s*正确|$)')

BEFORE = '1 【单选题】生涯规划就是职业生涯规划？A.对B.错 关闭'
AFTER = '1 正确 【单选题】生涯规划就是职业生涯规划？A.对B.错 正确答案：B关闭'


def parse(text):
    cleaned = STRIP_ANSWER.sub(' ', text)
    cleaned = re.sub(r'\s+', ' ', cleaned).strip()
    head = HEAD.search(cleaned)
    if not head:
        return None
    options = [(m.group(1), m.group(2).strip()) for m in OPT.finditer(cleaned) if m.group(2).strip()]
    return {'type': head.group(1), 'question': head.group(2).strip(), 'options': options}


def main():
    for label, text in (('答题前', BEFORE), ('答题后', AFTER)):
        quiz = parse(text)
        print(f'{label}: {quiz}')
        assert quiz, f'{label} 解析失败'
        assert quiz['question'] == '生涯规划就是职业生涯规划？', quiz['question']
        assert quiz['options'] == [('A', '对'), ('B', '错')], quiz['options']

    # ask_ai 的兜底清理也要能去掉这个尾巴
    cleaned = re.sub(r'正确答案\s*[:：].*$', '', 'B. 错 正确答案：B').strip()
    print('ask_ai 清理后:', repr(cleaned))
    assert cleaned == 'B. 错', cleaned

    # 选项文字里不该再出现「正确」
    after = parse(AFTER)
    assert all('正确' not in text for _, text in after['options']), after['options']
    print('\nOK: 「正确答案」不会再污染选项')


if __name__ == '__main__':
    main()
"""UI 的浏览器侧 worker。

用 JSON 行和 UI 通信（stdout 只输出 JSON；库的 print 已重定向到 stderr）。

命令：
  list                                 列出智慧课程 + 翻转课
  homework --course ID                 列出某门翻转课的作业/测验
  answer --course ID --homework ID --title T
                                       打开指定作业/测验，抓题 -> 等 UI 回传答案 -> 提交

answer 命令是交互式的：抓完题后输出 {"event":"questions",...} 和
{"event":"await"}，然后从 stdin 读一行 JSON：
  {"action":"submit","answers":[{"index":0,"letter":"C"},...]}
  {"action":"skip"}
"""
import argparse
import json
import sys
import time
from pathlib import Path
from urllib.parse import unquote

HERE = Path(__file__).resolve().parent
PROFILE = HERE / '.session'
STATE = PROFILE / 'auth-state.json'

OUT = sys.stdout
sys.stdout = sys.stderr  # 库里的 print 走 stderr，stdout 只留给协议

LIST_API = 'https://hiexam-server.zhihuishu.com/zhsathome/homeworkUser/List'
WENDA_LIST = 'https://wenda.zhihuishu.com/stu/courseInfo/homeworkExam?courseId={course}'
DETAIL = ('https://hiexam.zhihuishu.com/atHomeworkExam/stu/homeworkQ/'
          'homeworkDetail/{homework}/doHomeWork/1/2/{course}')


def emit(**payload):
    OUT.write(json.dumps(payload, ensure_ascii=False) + '\n')
    OUT.flush()


def log(text):
    emit(event='log', text=str(text))


def die(message):
    emit(event='error', message=str(message))
    raise SystemExit(1)


def open_context(playwright, headless=True):
    context = playwright.chromium.launch_persistent_context(
        str(PROFILE), headless=headless, channel='msedge',
        service_workers='block', viewport={'width': 1440, 'height': 900})
    if STATE.exists():
        try:
            context.add_cookies(json.loads(STATE.read_text(encoding='utf-8')).get('cookies', []))
        except Exception:
            pass
    return context


def uuid_of(context):
    for cookie in context.cookies():
        if cookie.get('name') == 'CASLOGC':
            try:
                return json.loads(unquote(cookie.get('value') or '')).get('uuid', '') or ''
            except Exception:
                return ''
    return ''


def ask():
    """从 stdin 读一行 JSON。"""
    line = sys.stdin.readline()
    if not line:
        return {'action': 'skip'}
    try:
        return json.loads(line)
    except Exception:
        return {'action': 'skip'}


def cmd_list(args):
    import run
    from playwright.sync_api import sync_playwright

    with sync_playwright() as playwright:
        context = open_context(playwright, headless=not args.show)
        page = context.pages[0] if context.pages else context.new_page()
        client = run.Client(page)
        context.route('**/run/gateway/t/stu/**', client.route)
        page.goto(f'https://{run.HOST}/mySpace', wait_until='domcontentloaded', timeout=60000)
        smart = run.wait_login(context, client, args.timeout)
        flip = []
        try:
            flip = run.FlipClient(context).courses()
        except run.ApiError as error:
            log(f'翻转课列表读取失败：{error}')
        context.storage_state(path=str(STATE))
        counts = run.course_breakdown(smart)
        if counts:
            log('识别到：' + '、'.join(f'{kind} {n} 门' for kind, n in counts.items()))
        if getattr(args, 'dump', False):
            log(f'课程字段核对：{json.dumps(run.course_fields(smart), ensure_ascii=False)}')
        emit(event='courses',
             smart=[{'id': c['course_id'], 'class_id': c['class_id'], 'name': c['name'],
                     'kind': c.get('kind', run.DEFAULT_KIND)} for c in smart],
             flip=[{'id': c['course_id'], 'name': c['name']} for c in flip])
        context.close()


def cmd_homework(args):
    from playwright.sync_api import sync_playwright

    with sync_playwright() as playwright:
        context = open_context(playwright, headless=True)
        uuid = uuid_of(context)
        if not uuid:
            die('登录状态失效，请先回界面点“读取课程”重新登录')
        data = context.request.get(LIST_API, params={
            'courseId': args.course, 'pageIndex': 1, 'pageSize': 50, 'key': '',
            'completeTab': 0, 'uuid': uuid, 'dateFormate': int(time.time() * 1000)}).json()
        if str(data.get('status')) != '200':
            die(f"作业列表接口返回 {data.get('status')}：{data.get('msg') or data.get('message')}")
        items = ((data.get('rt') or {}).get('list')) or []
        emit(event='homework', course_id=args.course, items=[{
            'homework_id': str(item.get('homeworkId')),
            'title': item.get('title'),
            'status': item.get('status'),
            'score': item.get('homeworkScore'),
            'end_time': item.get('endTime'),
            'content': item.get('content') or '',
        } for item in items])
        context.close()


def fetch_questions(context, homework_id, uuid):
    """用答题卡接口按顺序取全部题目，页面一次只渲染一题也不影响。"""
    base = 'https://hiexam-server.zhihuishu.com/zhsathome/homeworkUserPaper'
    now = int(time.time() * 1000)
    card = context.request.get(base + '/getAnswerCard', params={
        'homeworkId': homework_id, 'uuid': uuid, 'dateFormate': now}).json()
    if str(card.get('status')) != '200':
        die(f"答题卡接口返回 {card.get('status')}：{card.get('msg') or card.get('message')}")
    rt = card.get('rt') or {}
    ids = []
    for group in rt.get('groupDtoList') or []:
        for question in group.get('questionDtos') or []:
            ids.append(str(question.get('questionId')))
    questions = []
    for index, question_id in enumerate(ids):
        data = context.request.get(base + '/getDoQuestSingle', params={
            'homeworkId': homework_id, 'questionId': question_id,
            'uuid': uuid, 'dateFormate': int(time.time() * 1000)}).json()
        item = data.get('rt') or {}
        options = []
        for option in item.get('questionOptionList') or []:
            try:
                sort = int(option.get('sort') or 0)
            except Exception:
                sort = 0
            options.append({'option_id': str(option.get('id')),
                            'letter': (chr(64 + sort) + '.') if sort else '',
                            'text': str(option.get('content') or '').strip()})
        options.sort(key=lambda option: option['letter'])
        questions.append({
            'index': index,
            'question_id': question_id,
            'title': str(item.get('questionName') or ''),
            'type_id': item.get('questionTypeId'),
            'content': str(item.get('content') or '').strip(),
            'options': options,
        })
    return questions


def cmd_answer(args):
    from playwright.sync_api import sync_playwright

    with sync_playwright() as playwright:
        context = open_context(playwright, headless=True)
        page = context.pages[0] if context.pages else context.new_page()
        page.goto(WENDA_LIST.format(course=args.course), wait_until='domcontentloaded', timeout=60000)
        page.wait_for_timeout(5000)
        item = page.locator('.homework-item', has=page.locator('.tit', has_text=args.title)).first
        if item.count() == 0:
            die(f'列表里找不到作业：{args.title}')
        button = item.locator('.btn.do').first
        if button.count() == 0:
            die('这个作业不是“开始做题”状态（可能已提交或已批阅），跳过')
        with context.expect_page(timeout=60000) as page_info:
            button.click()
        detail = page_info.value
        detail.wait_for_load_state('domcontentloaded')
        try:
            detail.wait_for_selector('.questionBox', timeout=60000)
        except Exception:
            die('打开答题页后没有出现题目，可能被风控或页面改版')
        detail.wait_for_timeout(1500)
        questions = fetch_questions(context, args.homework, uuid_of(context))
        if not questions:
            die('没有抓到题目')
        emit(event='questions', course_id=args.course, homework_id=args.homework,
             title=args.title, questions=questions)
        emit(event='await')
        decision = ask()
        if decision.get('action') != 'submit':
            emit(event='skipped', message='已取消，未提交')
            context.close()
            return
        answers = {int(a.get('index', -1)): str(a.get('letter', '')).strip()
                   for a in decision.get('answers') or []}
        picked = 0
        cards = detail.locator('.jobclassallnumber-div ul li')
        for question in questions:
            letters = [c for c in answers.get(question['index'], '').upper() if c.isalpha()]
            if not letters:
                continue
            if question.get('type_id') not in (1, 2, 3):
                log(f"第 {question['index'] + 1} 题是 {question.get('title') or '未知题型'}，"
                    f"本版本只自动做客观题，跳过")
                continue
            try:
                if cards.count() > question['index']:
                    cards.nth(question['index']).click(timeout=5000)
                    detail.wait_for_timeout(500)
            except Exception:
                log(f"第 {question['index'] + 1} 题切换失败，仍尝试直接点选项")
            for letter in letters:
                option = next((o for o in question['options']
                               if o['letter'].rstrip('.').upper() == letter), None)
                if not option or not option['option_id']:
                    log(f"第 {question['index'] + 1} 题找不到选项 {letter}")
                    continue
                try:
                    detail.locator(
                        f'label.el-radio:has(input.el-radio__original[value="{option["option_id"]}"])'
                    ).first.click(timeout=5000)
                    detail.wait_for_timeout(250)
                    picked += 1
                except Exception as error:
                    log(f"第 {question['index'] + 1} 题选项 {letter} 点击失败：{error}")
        log(f'已勾选 {picked}/{len(questions)} 题，准备提交')
        detail.locator('.Submithomeworkbtn').first.click()
        detail.wait_for_timeout(1200)
        for _ in range(3):
            confirm = detail.locator('button.Submissionbtn', has_text='提交')
            if confirm.count() == 0:
                break
            try:
                confirm.last.click(timeout=5000)
                detail.wait_for_timeout(1500)
            except Exception:
                break
        detail.wait_for_timeout(2500)
        body = ''
        try:
            body = detail.inner_text('body')
        except Exception:
            pass
        emit(event='submitted', message='已提交', success_hint=('成功' in body or '提交成功' in body))
        context.storage_state(path=str(STATE))
        context.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=('list', 'homework', 'answer'))
    parser.add_argument('--course')
    parser.add_argument('--homework')
    parser.add_argument('--title')
    parser.add_argument('--show', action='store_true', help='列课程时显示浏览器窗口')
    parser.add_argument('--dump', action='store_true', help='列课程时输出课程类型字段核对信息')
    parser.add_argument('--timeout', type=int, default=600)
    args = parser.parse_args()
    if args.command == 'list':
        cmd_list(args)
    elif args.command == 'homework':
        if not args.course:
            die('homework 需要 --course')
        cmd_homework(args)
    else:
        if not (args.course and args.homework and args.title):
            die('answer 需要 --course/--homework/--title')
        cmd_answer(args)


if __name__ == '__main__':
    # OUT 是模块加载时抓住的原始 stdout；必须重配它，否则中文按 GBK 写出，
    # UI 那边按 UTF-8 读就会变成乱码。
    for stream in (OUT, sys.stderr):
        if hasattr(stream, 'reconfigure'):
            try:
                stream.reconfigure(encoding='utf-8', errors='replace')
            except Exception:
                pass
    main()
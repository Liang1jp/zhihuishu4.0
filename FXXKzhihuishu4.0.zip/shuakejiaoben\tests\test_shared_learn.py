"""Verify catalog/progress parsing with self-contained fixtures (no real data)."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'script'))
import shared_learn  # noqa: E402

# Shape mirrors the real videolist payload: one plain lesson, one with sub-videos.
VIDEOLIST = {
    'code': 0,
    'data': {
        'videoChapterDtos': [
            {'id': 101, 'name': '第一章', 'isPass': 1, 'videoLessons': [
                {'id': 201, 'name': '第一节', 'videoId': 301, 'videoSec': 600,
                 'isStudiedLesson': 0},
                {'id': 202, 'name': '第二节', 'ishaveChildrenLesson': 1, 'videoSmallLessons': [
                    {'id': 203, 'name': '第二节（上）', 'videoId': 302, 'videoSec': 300},
                    {'id': 204, 'name': '第二节（下）', 'videoId': 303, 'videoSec': 400},
                ]},
            ]},
            {'id': 102, 'name': '第二章', 'isPass': 0, 'videoLessons': [
                {'id': 205, 'name': '第三节', 'videoId': 304, 'videoSec': 500},
            ]},
        ],
    },
}

STUY = {
    'code': 0,
    'data': {
        'lesson': {'201': {'studyTotalTime': 600, 'watchState': 1}},
        'lv': {'203': {'studyTotalTime': 100, 'watchState': 2},
               '204': {'studyTotalTime': 0, 'watchState': 0}},
    },
}


def main():
    units = shared_learn.catalog_from(VIDEOLIST)
    print('units:', [(u['id'], u['name'], u['videoSec']) for u in units])

    # Sub-video lessons must be flattened, keeping the parent lesson id.
    assert [u['id'] for u in units] == [201, 203, 204, 205], 'flattening order'
    sub = next(u for u in units if u['id'] == 203)
    assert sub['lessonId'] == 202, 'sub-video must remember its parent lesson'
    assert sub['chapter'] == '第一章' and sub['videoSec'] == 300

    progress = shared_learn.progress_from(STUY)
    print('progress:', progress)
    assert progress['201']['watchState'] == 1
    assert progress['203']['watchState'] == 2, 'lv group must be merged'

    done = [u for u in units if (progress.get(str(u['id'])) or {}).get('watchState') == 1]
    todo = [u for u in units if (progress.get(str(u['id'])) or {}).get('watchState') != 1]
    assert [u['id'] for u in done] == [201]
    assert [u['id'] for u in todo] == [203, 204, 205]

    # Missing entries must not crash the todo filter.
    assert shared_learn.progress_from({'data': None}) == {}
    assert shared_learn.catalog_from({'data': None}) == []
    print('\nOK: catalog flattening and progress merge behave correctly')


if __name__ == '__main__':
    main()
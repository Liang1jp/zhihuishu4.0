"""共享课（老平台）学习引擎 —— 驱动页面自己完成学习记录。

它不伪造任何请求：播放、上报、完成标记全部由页面自己的加密通道发出，
所以参数和真人操作一致。

用法：
    python script\\shared_learn.py --limit 1        # 只跑 1 节，验证通路
    python script\\shared_learn.py                  # 跑完全部未完成
    python script\\shared_learn.py --rate 2         # 2 倍速（播放器官方上限）

安全设计：
  - 以服务端 queryStuyInfo 的 watchState 为准判断完成，不靠页面显示；
  - 每节跑完回读一次状态，确认不了就记 not_confirmed，绝不谎报；
  - 检测到弹题会尝试作答（用服务端返回的答案），答不了就停下等你。
"""
import argparse
import json
import random
import re
import sys
import time
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROFILE = ROOT / '.session'
OUTPUT = ROOT / 'output'
SHARED_HOST = 'studyvideoh5.zhihuishu.com'
RNG = random.Random()
URL_HINT = ('https://studyvideoh5.zhihuishu.com/stuStudy'
            '?recruitAndCourseId=＜你自己的编号＞')

# 抹掉自动化浏览器最明显的两个标记：navigator.webdriver 和 window.chrome。
# 平台只要一行 JS 就能查到 webdriver=true，这是最容易暴露的一点。
STEALTH_JS = r"""Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
if (!window.chrome) { window.chrome = {runtime: {}}; }
if (navigator.languages && navigator.languages.length === 0) {
    Object.defineProperty(navigator, 'languages', {get: () => ['zh-CN', 'zh']});
}"""

# 元素中心点坐标，用来走真实鼠标轨迹，而不是 JS 直接 .click()
UNIT_POINT_JS = r"""(i) => {
    const el = document.querySelectorAll('.video')[i];
    if (!el) return null;
    el.scrollIntoView({block: 'center'});
    const r = el.getBoundingClientRect();
    if (r.width < 4 || r.height < 4) return null;
    return {x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2)};
}"""

# 页面上的可播放单元
UNITS_JS = r"""() => [...document.querySelectorAll('.video')].map((el, i) => {
    const title = el.querySelector('.catalogue_title');
    const sub = el.querySelector('.catalogue_title4');
    return {
        i,
        title: title ? title.textContent.trim().slice(0, 80) : '',
        sub: sub ? sub.textContent.trim().slice(0, 80) : '',
        full: (el.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 160),
    };
})"""

PLAY_JS = r"""(rate) => {
    const list = [...document.querySelectorAll('video')]
        .filter((v) => v.clientWidth >= 100 && v.clientHeight >= 60);
    list.sort((a, b) => (b.clientWidth * b.clientHeight) - (a.clientWidth * a.clientHeight));
    const v = list[0] || document.querySelector('video');
    if (!v) return {ok: false, reason: 'no video element'};
    try { v.playbackRate = rate; } catch (error) {}
    let error = null;
    let promise = null;
    try { promise = v.play(); } catch (err) { error = String(err && err.name || err); }
    if (promise && typeof promise.catch === 'function') {
        promise.catch((err) => { window.__lastPlayError = String(err && err.name || err); });
    }
    const rect = v.getBoundingClientRect();
    return {ok: true, rate: v.playbackRate, duration: v.duration,
            current: v.currentTime, paused: v.paused, ready: v.readyState,
            error,
            center: {x: rect.x + rect.width / 2, y: rect.y + rect.height / 2},
            size: {w: rect.width, h: rect.height}};
}"""

# 播放器的大播放按钮（video.js 等）
CLICK_PLAY_JS = r"""() => {
    const candidates = [
        '.vjs-big-play-button', '.vjs-play-control', '.prism-big-play-btn',
        '[class*=big-play]', '[class*=play-btn]', '[class*=playBtn]',
    ];
    for (const selector of candidates) {
        for (const btn of document.querySelectorAll(selector)) {
            const st = window.getComputedStyle(btn);
            if (st.display === 'none' || st.visibility === 'hidden') continue;
            const rect = btn.getBoundingClientRect();
            if (rect.width < 4 || rect.height < 4) continue;
            btn.click();
            return {ok: true, selector,
                    x: rect.x + rect.width / 2, y: rect.y + rect.height / 2};
        }
    }
    return {ok: false};
}"""

STATE_JS = r"""() => {
    // 页面上可能同时有预览小窗和主播放器，取面积最大的那个才是正在学的视频
    const list = [...document.querySelectorAll('video')]
        .filter((v) => v.clientWidth >= 100 && v.clientHeight >= 60);
    list.sort((a, b) => (b.clientWidth * b.clientHeight) - (a.clientWidth * a.clientHeight));
    const v = list[0] || document.querySelector('video');
    if (!v) return {ok: false};
    return {ok: true, current: v.currentTime, duration: v.duration,
            paused: v.paused, ended: v.ended, rate: v.playbackRate,
            ready: v.readyState, size: v.clientWidth + 'x' + v.clientHeight};
}"""

# 页面上的遮罩/提示框：只用来判断「有没有东西挡着」，不负责判断是不是题目。
# 「温馨提示 / 我知道了」这种纯提示必须能关掉，否则视频会被挡住、计时也会停。
PROMPT_JS = r"""() => {
    const found = [];
    document.querySelectorAll('div, section').forEach((el) => {
        const cls = typeof el.className === 'string' ? el.className : '';
        if (!/dialog|modal|popup|mask|layer|tips|notice|message/i.test(cls)) return;
        const style = window.getComputedStyle(el);
        if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return;
        if (el.offsetParent === null && style.position !== 'fixed') return;
        const text = (el.textContent || '').replace(/\s+/g, ' ').trim();
        if (text.length < 2 || text.length > 500) return;
        found.push({cls: cls.slice(0, 80), text: text.slice(0, 200),
                    html: el.innerHTML.slice(0, 500)});
    });
    return found;
}"""

# 点掉「我知道了 / 确定」这类按钮。
# 先按对话框类容器找，找不到再全局找唯一性高的文字（「我知道了」这种词页面上不会有两处）。
DISMISS_JS = r"""() => {
    const DIALOG_LABELS = ['我知道了', '知道了', '我已知晓', '不再提示', '确定', '继续', '关闭', '好的'];
    const UNIQUE_LABELS = ['我知道了', '知道了', '我已知晓', '不再提示', '关闭'];
    const visible = (el) => {
        const st = window.getComputedStyle(el);
        if (st.display === 'none' || st.visibility === 'hidden' || st.opacity === '0') return false;
        const rect = el.getBoundingClientRect();
        return rect.width >= 8 && rect.height >= 8;
    };
    const usable = (el) => {
        if (!visible(el)) return false;
        if (el.closest('.video-js') || el.closest('.speedList')) return false;
        return true;
    };

    const scopes = [];
    document.querySelectorAll(
        '[class*=dialog],[class*=modal],[class*=popup],[class*=mask],' +
        '[class*=layer],[class*=message],[class*=notice],[class*=tips]'
    ).forEach((el) => { if (visible(el)) scopes.push(el); });

    // 1) 对话框里的文字按钮
    for (const scope of scopes) {
        for (const el of scope.querySelectorAll('button, a, span, div')) {
            const text = (el.textContent || '').trim();
            if (!DIALOG_LABELS.includes(text) || !visible(el)) continue;
            el.click();
            return {ok: true, label: text, scope: 'dialog'};
        }
    }
    // 2) 对话框右上角的 ×（这个弹题有 button.el-dialog__headerbtn）
    for (const scope of scopes) {
        const closeBtn = scope.querySelector(
            'button.el-dialog__headerbtn, [class*=close], ' +
            '[aria-label*=Close], [aria-label*=close]');
        if (closeBtn && usable(closeBtn)) {
            closeBtn.click();
            return {ok: true, label: '×', scope: 'dialog-close'};
        }
    }
    // 3) 全局兜底：文字唯一性够高的按钮（视频控件区除外）
    for (const el of document.querySelectorAll('button, a, span, div')) {
        const text = (el.textContent || '').trim();
        if (!UNIQUE_LABELS.includes(text) || !usable(el)) continue;
        el.click();
        return {ok: true, label: text, scope: 'global'};
    }
    return {ok: false};
}"""

# 按服务端给的题目/答案，在弹窗里选对应选项
ANSWER_JS = r"""(questionText, optionText) => {
    const clean = (value) => String(value || '').replace(/<[^>]*>/g, '').replace(/\s+/g, '');
    const visible = (el) => {
        const st = window.getComputedStyle(el);
        return st.display !== 'none' && st.visibility !== 'hidden' && st.opacity !== '0';
    };

    const needle = clean(questionText).slice(0, 12);
    if (!needle) return {ok: false, reason: 'no question text'};

    // 找出包含题干的最小可见容器
    let holder = null;
    for (const el of document.querySelectorAll('div, section, form, ul')) {
        if (!visible(el)) continue;
        if (!clean(el.textContent).includes(needle)) continue;
        if (!holder || el.textContent.length < holder.textContent.length) holder = el;
    }
    if (!holder) return {ok: false, reason: 'question not found'};

    // 在容器里按选项文字找最小可点击节点
    const want = clean(optionText);
    const hits = [];
    for (const el of holder.querySelectorAll('label, li, div, span, a, button, p')) {
        if (!visible(el)) continue;
        const text = clean(el.textContent);
        if (!text || text.length > want.length + 6) continue;
        if (text !== want && !text.includes(want) && !want.includes(text)) continue;
        hits.push(el);
    }
    if (!hits.length) {
        return {ok: false, reason: 'option not found', html: holder.innerHTML.slice(0, 600)};
    }
    hits.sort((a, b) => a.textContent.length - b.textContent.length);
    const target = hits[0];
    target.click();
    return {ok: true, clicked: clean(target.textContent).slice(0, 40),
            tag: target.tagName, cls: String(target.className).slice(0, 60)};
}"""

SUBMIT_JS = r"""() => {
    const visible = (el) => {
        const st = window.getComputedStyle(el);
        if (st.display === 'none' || st.visibility === 'hidden' || st.opacity === '0') return false;
        const rect = el.getBoundingClientRect();
        return rect.width >= 8 && rect.height >= 8;
    };
    // 真实弹题只给「关闭」，没有「提交」，所以两者都要认
    const labels = ['提交', '确定', '继续', '下一题', '确认', '我知道了', '关闭'];
    for (const el of document.querySelectorAll('button, a, div, span')) {
        const text = (el.textContent || '').trim();
        if (!labels.includes(text)) continue;
        if (!visible(el)) continue;
        el.click();
        return {ok: true, label: text};
    }
    return {ok: false};
}"""


def eval_every_frame(page, script, *args):
    """在所有 frame（含 iframe）里执行脚本，聚合非空结果。

    真实的「AI助教出题」弹窗和部分提示条在 iframe 里，只查主 frame 会漏掉。
    """
    results = []
    for frame in page.frames:
        try:
            value = frame.evaluate(script, *args)
        except Exception:
            continue
        if not value:
            continue
        if isinstance(value, list):
            results.extend(value)
        else:
            results.append(value)
    return results


def dismiss_any(page):
    """在所有 frame 里试着关掉提示框，返回第一个成功的结果。"""
    for frame in page.frames:
        try:
            result = frame.evaluate(DISMISS_JS)
        except Exception:
            continue
        if result and result.get('ok'):
            return result
    return None


# 答不出来时把页面里「像题目」的片段抓出来，方便定位真实结构
PROBE_DIALOG_JS = r"""() => {
    const out = [];
    document.querySelectorAll('div, section, form, li, label').forEach((el) => {
        const text = (el.textContent || '').replace(/\s+/g, ' ').trim();
        if (text.length < 4 || text.length > 400) return;
        if (!/[？?]|对|错|题/.test(text)) return;
        const st = window.getComputedStyle(el);
        if (st.display === 'none' || st.visibility === 'hidden') return;
        out.push({
            cls: String(el.className || '').slice(0, 60),
            tag: el.tagName,
            text: text.slice(0, 150),
            radio: !!el.querySelector('input[type=radio]'),
            // 存一段精简后的 HTML，失败时照着它写精确选择器
            html: el.outerHTML
                .replace(/<svg[\s\S]*?<\/svg>/gi, '<svg/>')
                .slice(0, 1200),
        });
    });
    return out.slice(0, 10);
}"""


def probe_frames(page):
    """把每个 frame 里「像题目」的片段记下来，答不出来时好定位。"""
    out = []
    for index, frame in enumerate(page.frames):
        try:
            items = frame.evaluate(PROBE_DIALOG_JS) or []
        except Exception:
            continue
        for item in items:
            item['frame'] = index
            item['url'] = (frame.url or '')[:100]
            out.append(item)
    return out[:12]


def wait_for_question(page, question_text, timeout=20):
    """等弹窗把题干渲染出来。

    必须在弹窗容器里判断：视频字幕里也可能出现同一句话，
    查整页 innerText 会误以为弹窗已经出现，然后立刻去点就点空了。
    """
    needle = re.sub(r'<[^>]*>', '', question_text or '').replace(' ', '')[:12]
    if not needle:
        return False
    print(f'  喵～等弹窗出现（最多 {timeout} 秒）…', flush=True)
    deadline = time.time() + timeout
    while time.time() < deadline:
        for frame in page.frames:
            try:
                hit = frame.evaluate(PLAYTOPIC_TEXT_JS, needle)
            except Exception:
                continue
            if hit:
                print('  喵～弹窗出来了', flush=True)
                return True
        page.wait_for_timeout(1000)
    print(f'  喵…{timeout} 秒内没等到弹窗题干', flush=True)
    return False


def answer_in_frames(page, question_text, option_text):
    """定位选项并用鼠标点。失败时先退回 Playwright 的文本定位，再报错。"""
    # 弹窗刚出现时有淡入动画，等它稳定再点
    page.wait_for_timeout(RNG.randint(700, 1500))

    reasons = []
    # 1) 按已知的 AI 助教弹窗结构精确点（最可靠）
    for frame in page.frames:
        try:
            result = frame.evaluate(PLAYTOPIC_POINT_JS, option_text)
        except Exception as error:
            reasons.append({'frame': (frame.url or '')[:60],
                            'error': type(error).__name__})
            continue
        if result and result.get('ok'):
            x, y = result['x'], result['y']
            try:
                if frame != page.main_frame:
                    box = frame.frame_element().bounding_box()
                    if box:
                        x += box['x']
                        y += box['y']
            except Exception:
                pass
            page.mouse.move(x, y, steps=RNG.randint(5, 12))
            page.wait_for_timeout(RNG.randint(120, 400))
            page.mouse.click(x, y)
            result['clicked_at'] = {'x': round(x), 'y': round(y)}
            return result
        reasons.append({'frame': (frame.url or '')[:60],
                        'reason': (result or {}).get('reason')})

    # 2) 通用定位兜底（别的弹题形态）
    for frame in page.frames:
        try:
            result = frame.evaluate(OPTION_POINT_JS, [question_text, option_text])
        except Exception as error:
            reasons.append({'frame': (frame.url or '')[:60],
                            'error': type(error).__name__})
            continue
        if not result or not result.get('ok'):
            reasons.append({'frame': (frame.url or '')[:60],
                            'reason': (result or {}).get('reason')})
            continue
        x, y = result['x'], result['y']
        # iframe 里的坐标要加上它自己的偏移
        try:
            if frame != page.main_frame:
                box = frame.frame_element().bounding_box()
                if box:
                    x += box['x']
                    y += box['y']
        except Exception:
            pass
        page.mouse.move(x, y, steps=RNG.randint(5, 12))
        page.wait_for_timeout(RNG.randint(120, 400))
        page.mouse.click(x, y)
        result['clicked_at'] = {'x': round(x), 'y': round(y)}
        return result

    # 兜底：交给 Playwright 的文本定位，它自带「等可见再点」
    try:
        target = page.locator('.el-dialog, .el-message-box, [class*=dialog]') \
                     .get_by_text(option_text, exact=False).last
        target.click(timeout=8000)
        return {'ok': True, 'mode': 'locator', 'text': option_text}
    except Exception as error:
        reasons.append({'locator': type(error).__name__})
    return {'ok': False, 'reason': 'option_not_found', 'tried': reasons}


def submit_in_frames(page):
    """点掉弹题的「提交 / 关闭」按钮。"""
    for frame in page.frames:
        try:
            result = frame.evaluate(SUBMIT_JS)
        except Exception:
            continue
        if result and result.get('ok'):
            return result
    return {'ok': False}


# 从弹窗文字里读出题目。AI 助教弹题的版式是：
#   【判断题】题干……
#   A. 对
#   B. 错
QUIZ_DOM_JS = r"""() => {
    const visible = (el) => {
        const st = window.getComputedStyle(el);
        if (st.display === 'none' || st.visibility === 'hidden' || st.opacity === '0') return false;
        const rect = el.getBoundingClientRect();
        return rect.width >= 40 && rect.height >= 20;
    };
    const boxes = [];
    document.querySelectorAll('div, section, form').forEach((el) => {
        if (!visible(el)) return;
        const text = (el.textContent || '').replace(/\s+/g, ' ');
        if (!/【[^】]{1,8}题】/.test(text)) return;
        if (!/[A-F][.、]/.test(text)) return;
        if (text.length > 2000) return;
        boxes.push({el, text, len: text.length});
    });
    if (!boxes.length) return null;
    boxes.sort((a, b) => a.len - b.len);
    let text = boxes[0].text.trim();
    // 答完题后页面会追加「正确 / 正确答案：B」，这部分不是题干也不是选项
    text = text.replace(/正确答案\s*[:：]\s*[A-F]?/g, ' ').replace(/\s+/g, ' ').trim();

    const head = /【([^】]{1,8}题)】\s*([\s\S]{4,400}?)(?=\s*[A-F][.、]|$)/.exec(text);
    if (!head) return null;

    const options = [];
    const optRe = /([A-F])[.、]\s*([\s\S]{1,60}?)(?=\s*[A-F][.、]|\s*提交|\s*关闭|\s*正确|$)/g;
    let match;
    while ((match = optRe.exec(text)) !== null) {
        const body = match[2].replace(/\s+/g, ' ').trim();
        if (body) options.push({letter: match[1], text: body});
    }
    if (!options.length) return null;
    return {type: head[1], question: head[2].replace(/\s+/g, ' ').trim(), options,
            scope: String(boxes[0].el.className || '').slice(0, 60)};
}"""


# 定位选项的坐标。
# 这个弹题（el-dialog + div.radio）的「对 / 错」不是独立元素，
# 只是整段文字里的一小块，所以先用「最小的包含选项文字的元素」，
# 找不到就用 Range 精确定位到那几个字的坐标，再用鼠标点。
OPTION_POINT_JS = r"""(questionText, optionText) => {
    const clean = (value) => String(value || '').replace(/<[^>]*>/g, '').replace(/\s+/g, '');
    const shown = (el) => {
        const st = window.getComputedStyle(el);
        if (st.display === 'none' || st.visibility === 'hidden') return false;
        // 不能因为 opacity 是 0 就跳过：Element UI 弹窗有淡入动画，
        // 那一瞬间 innerText 已经有字了，但 opacity 还没到 1。
        const rect = el.getBoundingClientRect();
        return rect.width >= 4 && rect.height >= 4;
    };

    const needle = clean(questionText).slice(0, 12);
    if (!needle) return {ok: false, reason: 'no question text'};

    // 找包含题干的最小可见容器
    let holder = null;
    for (const el of document.querySelectorAll('div, section, form, ul')) {
        if (!shown(el)) continue;
        if (!clean(el.textContent).includes(needle)) continue;
        if (!holder || el.textContent.length < holder.textContent.length) holder = el;
    }
    if (!holder) return {ok: false, reason: 'question not found'};

    const want = clean(optionText);
    if (!want) return {ok: false, reason: 'no option text'};

    // 1) 文字几乎就等于选项本身（独立选项元素），点它的中心
    let best = null;
    let bestLen = Infinity;
    for (const el of holder.querySelectorAll('*')) {
        const text = clean(el.textContent);
        if (!text || !text.includes(want)) continue;
        if (!shown(el)) continue;
        if (text.length < bestLen) { best = el; bestLen = text.length; }
    }
    if (best && bestLen <= want.length + 3) {
        const rect = best.getBoundingClientRect();
        return {ok: true, mode: 'element', x: rect.x + rect.width / 2,
                y: rect.y + rect.height / 2, text: clean(best.textContent).slice(0, 30)};
    }

    // 2) 选项混在一段文字里（这个弹题就是），用 Range 框出那几个字，
    //    并取「最后一次」出现 —— 选项总在题干后面，避免点到题干里的同一个字。
    const walker = document.createTreeWalker(holder, NodeFilter.SHOW_TEXT);
    const range = document.createRange();
    let lastRect = null;
    let node;
    while ((node = walker.nextNode())) {
        const content = node.textContent || '';
        let from = 0;
        let idx;
        while ((idx = content.indexOf(want, from)) !== -1) {
            range.setStart(node, idx);
            range.setEnd(node, idx + want.length);
            const rect = range.getBoundingClientRect();
            if (rect.width >= 2 && rect.height >= 2) lastRect = rect;
            from = idx + want.length;
        }
    }
    if (lastRect) {
        return {ok: true, mode: 'range', x: lastRect.x + lastRect.width / 2,
                y: lastRect.y + lastRect.height / 2};
    }
    return {ok: false, reason: 'option not found'};
}"""


# 「AI助教出题」弹窗的真实结构（从页面 HTML 抓到的）：
#   #playTopic-dialog
#     └ .el-dialog__body .topic
#         ├ .topic-title   【单选题】生涯就是生活。
#         └ ul.topic-list
#             ├ li.topic-item  A. [.item-topic] 对
#             └ li.topic-item  B. [.item-topic] 错
# 直接按这个结构点，不再靠文字猜容器。
PLAYTOPIC_POINT_JS = r"""(optionText) => {
    const flat = (value) => String(value || '').replace(/\s+/g, '');
    const want = flat(optionText);
    if (!want) return {ok: false, reason: 'no option text'};

    const dialogs = document.querySelectorAll(
        '#playTopic-dialog, .el-dialog__wrapper.dialog-test, .el-dialog__wrapper');
    for (const dialog of dialogs) {
        const st = window.getComputedStyle(dialog);
        if (st.display === 'none' || st.visibility === 'hidden') continue;
        for (const item of dialog.querySelectorAll('.topic-item')) {
            const text = flat(item.textContent);
            if (!text.includes(want)) continue;
            const target = item.querySelector('.item-topic') || item;
            const rect = target.getBoundingClientRect();
            if (rect.width < 4 || rect.height < 4) continue;
            return {ok: true, mode: 'playtopic', x: rect.x + rect.width / 2,
                    y: rect.y + rect.height / 2, text};
        }
    }
    return {ok: false, reason: 'no topic-item matched'};
}"""

# 只在这个弹窗里找题干，避免把视频字幕里的同一句话当成弹窗
PLAYTOPIC_TEXT_JS = r"""(needle) => {
    const flat = (value) => String(value || '').replace(/\s+/g, '');
    const target = flat(needle);
    if (!target) return false;
    const dialogs = document.querySelectorAll(
        '#playTopic-dialog, .el-dialog__wrapper.dialog-test');
    for (const dialog of dialogs) {
        const st = window.getComputedStyle(dialog);
        if (st.display === 'none' || st.visibility === 'hidden') continue;
        const body = dialog.querySelector('.el-dialog__body') || dialog;
        if (flat(body.textContent).includes(target)) return true;
    }
    return false;
}"""


# 读某个节在左侧目录里的进度（百分比 / 完成图标）
UNIT_PROGRESS_JS = r"""(i) => {
    const el = document.querySelectorAll('.video')[i];
    if (!el) return null;
    const text = (el.textContent || '').replace(/\s+/g, '');
    const percent = /(\d{1,3})%/.exec(text);
    const icon = el.querySelector(
        '[class*=status],[class*=finish],[class*=complete],[class*=check],[class*=dui]');
    let iconClass = '';
    if (icon) {
        iconClass = typeof icon.className === 'string' ? icon.className : '';
    }
    return {
        percent: percent ? Number(percent[1]) : null,
        iconClass: iconClass.slice(0, 60),
        text: text.slice(0, 100),
    };
}"""

# 把当前视频倒回开头
REWIND_JS = r"""() => {
    const list = [...document.querySelectorAll('video')]
        .filter((v) => v.clientWidth >= 100 && v.clientHeight >= 60);
    list.sort((a, b) => (b.clientWidth * b.clientHeight) - (a.clientWidth * a.clientHeight));
    const v = list[0] || document.querySelector('video');
    if (!v) return {ok: false};
    try { v.currentTime = 0; } catch (e) {}
    let p = null;
    try { p = v.play(); } catch (e) {}
    if (p && typeof p.catch === 'function') p.catch(() => {});
    return {ok: true, current: v.currentTime, paused: v.paused};
}"""


def ensure_playing(page, rate):
    """让视频真的播起来。

    三级兜底：直接 play() → 点播放器的大播放按钮 → 真实鼠标点视频中心。
    浏览器的自动播放策略要求「用户手势」，最后一步的真实点击就是干这个的。
    """
    result = page.evaluate(PLAY_JS, rate) or {}
    page.wait_for_timeout(700)
    status = page.evaluate(STATE_JS) or {}
    if status.get('ok') and not status.get('paused'):
        return status
    if not status.get('ok'):
        return status

    clicked = page.evaluate(CLICK_PLAY_JS) or {}
    if clicked.get('ok'):
        page.wait_for_timeout(900)
        status = page.evaluate(STATE_JS) or {}
        if status.get('ok') and not status.get('paused'):
            return status

    center = result.get('center') or {}
    if center.get('x') and center.get('y'):
        page.mouse.move(center['x'], center['y'], steps=RNG.randint(4, 10))
        page.wait_for_timeout(RNG.randint(120, 400))
        page.mouse.click(center['x'], center['y'])
        page.wait_for_timeout(900)
    return page.evaluate(STATE_JS) or status


def close_dialog(page):
    """关掉「AI助教出题」弹窗。

    手写 JS 的 .click() 有时候触发不了 Vue 的事件，所以这里优先用
    Playwright 的定位器（它会真的派发鼠标事件），最后再按 Escape 兜底。
    """
    selectors = [
        '#playTopic-dialog .el-dialog__footer button',
        '#playTopic-dialog button.el-dialog__headerbtn',
        '.el-dialog__wrapper.dialog-test button.el-dialog__headerbtn',
        '.el-dialog__wrapper.dialog-test .el-dialog__footer button',
    ]
    for selector in selectors:
        try:
            locator = page.locator(selector).first
            if locator.count() == 0:
                continue
            locator.click(timeout=4000)
            return {'ok': True, 'via': selector}
        except Exception:
            continue

    # 按文字点「关闭」
    for text in ('关闭', '我知道了', '确定'):
        try:
            locator = page.locator('#playTopic-dialog, .el-dialog__wrapper') \
                         .get_by_text(text, exact=True).last
            if locator.count() == 0:
                continue
            locator.click(timeout=4000)
            return {'ok': True, 'via': f'text:{text}'}
        except Exception:
            continue

    # 最后试 Esc（Element UI 默认允许按 Esc 关闭）
    try:
        page.keyboard.press('Escape')
        return {'ok': True, 'via': 'Escape'}
    except Exception as error:
        return {'ok': False, 'error': type(error).__name__}


def dialog_visible(page):
    """弹窗还在不在（只认这个 AI 助教弹窗，别被其它浮层误导）。"""
    script = ("() => {const d = document.querySelector("
              "'#playTopic-dialog, .el-dialog__wrapper.dialog-test');"
              "if (!d) return false;"
              "const st = getComputedStyle(d);"
              "return st.display !== 'none' && st.visibility !== 'hidden';}")
    for frame in page.frames:
        try:
            if frame.evaluate(script):
                return True
        except Exception:
            continue
    return False


def read_quiz_from_frames(page):
    """从弹窗 DOM 里直接读题目，返回 {type, question, options} 或 None。

    「AI助教小智给你出题啦」这类弹题不走 lessonPopupExam 接口，
    只能把它显示在页面上的文字读出来。
    """
    for frame in page.frames:
        try:
            quiz = frame.evaluate(QUIZ_DOM_JS)
        except Exception:
            continue
        if quiz and quiz.get('options'):
            quiz['frame_url'] = frame.url[:120]
            return quiz
    return None


def answer_dom_quiz(page, quiz, entry, ai_client):
    """用 DeepSeek 判断弹窗题的答案，点选项，再点关闭。"""
    if ai_client is None:
        entry['quiz_error'] = 'ai_not_configured'
        return False
    try:
        choice = ask_ai(ai_client, {
            'question': quiz['question'],
            'type': quiz.get('type') or '判断题',
            'options': [{'content': f"{o['letter']}. {o['text']}"} for o in quiz['options']],
        })
    except Exception as error:
        entry['quiz_error'] = f'ai_failed: {type(error).__name__}'
        return False

    entry['quiz_question'] = quiz['question'][:160]
    entry['quiz_answer'] = {'text': choice['text'], 'source': choice['source']}
    picked = answer_in_frames(page, quiz['question'], choice['text'])
    entry['quiz_pick'] = picked
    if not picked or not picked.get('ok'):
        entry['quiz_probe'] = probe_frames(page)
        return False

    page.wait_for_timeout(RNG.randint(700, 1600))
    # 这种弹窗只有「关闭」，没有提交
    entry['quiz_close'] = close_dialog(page) or submit_in_frames(page)
    return True


def watch_state(value):
    """把 watchState 统一成整数：1 / "1" / 1.0 / " 1 " 都算 1。"""
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return None


def needs_study(progress_entry, video_sec):
    """这一节要不要刷。

    两处坑：
      1. watchState 可能是数字 1、字符串 "1" 或 1.0，只跟一种比会整片误判；
      2. 服务端有时把节标成完成，但 studyTotalTime 远小于视频时长，
         这种「假完成」要重新刷，否则会漏掉大量没学的节。
    """
    entry = progress_entry or {}
    studied = entry.get('studyTotalTime') or 0
    total = video_sec or 0
    if watch_state(entry.get('watchState')) != 1:
        return True
    if total and studied < total * 0.5:
        return True
    return False


def extract_quiz(payload):
    """从 lessonPopupExam 响应里取出题干、选项和可能的正确答案。

    答案有两个来源：
      1. zAnswer —— 只有「已经答过」的题才有，所以通常为 None；
      2. 选项自带的 result 字段 —— 单选题里恰有一个是 "1"，
         两次真实抓包里它都指向 zAnswer 的同一项，可以作为可靠线索。
    两者都拿不到时返回 known=None，交给 AI 判断。
    """
    items = ((payload or {}).get('data') or {}).get('lessonTestQuestionUseInterfaceDtos') or []
    if not items:
        return None
    item = items[0]
    question = item.get('testQuestion') or {}
    options = [{'id': o.get('id'), 'content': o.get('content') or '',
                'result': o.get('result')} for o in (question.get('questionOptions') or [])]
    if not options:
        return None

    known = None
    answer_id = (item.get('zAnswer') or {}).get('answer')
    if answer_id:
        known = next((o for o in options if str(o['id']) == str(answer_id)), None)
        if known:
            known = {'id': known['id'], 'text': known['content'], 'source': 'zAnswer'}
    if not known:
        marked = [o for o in options if str(o.get('result')) == '1']
        if len(marked) == 1:
            known = {'id': marked[0]['id'], 'text': marked[0]['content'], 'source': 'option-flag'}

    return {'question': question.get('name') or '',
            'type': (question.get('questionType') or {}).get('name') or '',
            'options': options, 'known': known}


def ask_ai(client, quiz):
    """让 DeepSeek 判断弹题答案，返回 {'id','text','source'}。"""
    stem = re.sub(r'<[^>]*>', '', quiz['question']).strip()
    prompt = [{'id': '0', 'type': quiz.get('type') or '单选题', 'stem': stem,
               'options': [{'letter': chr(65 + i), 'text': o['content']}
                           for i, o in enumerate(quiz['options'])]}]
    answers = client.answer_questions(prompt, '')
    letter = str((answers[0] or {}).get('answer', '')).strip().upper()
    letter = next((ch for ch in letter if 'A' <= ch <= 'Z'), '')
    index = ord(letter) - 65 if letter else -1
    if not 0 <= index < len(quiz['options']):
        raise ValueError('AI 答案对不上选项')
    option = quiz['options'][index]
    # 接口来的选项用 content，DOM 读出来的用 text，两种都认
    text = option.get('content') or option.get('text') or ''
    # 兜底清掉「正确答案：B」这类答题后追加的文字
    text = re.sub(r'正确答案\s*[:：].*$', '', str(text)).strip()
    return {'id': option.get('id'), 'text': text, 'source': 'deepseek'}


def quiz_ready(state, now=None, ttl=120):
    """只有「刚收到弹题数据」且「能解析出题目」时才返回题目，否则 None。

    这条判断很关键：页面上「温馨提示 / 我知道了」之类的纯提示框没有
    lessonPopupExam 数据，必须走「点掉提示」的分支，不能被当成弹题。
    """
    if not state.get('quiz'):
        return None
    now = time.time() if now is None else now
    if now - (state.get('last_quiz') or 0) > ttl:
        return None
    return extract_quiz(state['quiz'])


def answer_one(page, quiz, entry, ai_client=None):
    """在弹题里选出答案并提交。拿不到答案就返回 False。"""
    if entry.get('quiz_rounds', 0) >= 5:
        entry['quiz_error'] = 'too_many_rounds'
        return False
    entry['quiz_rounds'] = entry.get('quiz_rounds', 0) + 1

    if not quiz:
        entry['quiz_error'] = 'no_quiz_in_payload'
        return False
    entry['quiz_question'] = re.sub(r'<[^>]*>', '', quiz['question'])[:160]
    entry['quiz_options'] = [o['content'] for o in quiz['options']]

    choice = quiz['known']
    if not choice and ai_client is not None:
        try:
            choice = ask_ai(ai_client, quiz)
        except Exception as error:
            entry['quiz_error'] = f'ai_failed: {type(error).__name__}'
    if not choice:
        entry['quiz_error'] = entry.get('quiz_error') or 'no_answer_available'
        return False

    entry['quiz_answer'] = {'text': choice['text'], 'source': choice['source']}
    # 接口响应常比弹窗渲染早一步，先等题干真的出现在页面上再点
    entry['quiz_visible'] = wait_for_question(page, quiz['question'], timeout=20)
    picked = answer_in_frames(page, quiz['question'], choice['text'])
    entry['quiz_pick'] = picked
    if not picked or not picked.get('ok'):
        entry['quiz_probe'] = probe_frames(page)
        return False

    # 这个弹题没有「提交」，只有「关闭」。有的版本要「提交 + 关闭」两步，
    # 而且手写 JS 的 click 可能触发不了 Vue 事件，所以多路尝试直到真的消失。
    closes = []
    for attempt in range(4):
        page.wait_for_timeout(RNG.randint(600, 1200))
        if not dialog_visible(page):
            break
        # 只针对 #playTopic-dialog 里的按钮点，别去碰顶部横幅的「不再提示」
        closed = (close_dialog(page) or submit_in_frames(page))
        if closed:
            closed['attempt'] = attempt + 1
            closes.append(closed)
        page.wait_for_timeout(800)
    entry['quiz_close'] = closes
    entry['quiz_still_open'] = dialog_visible(page)
    if entry['quiz_still_open']:
        print('  喵…弹窗还赖着不走，再按 Esc 试试', flush=True)
        try:
            page.keyboard.press('Escape')
            page.wait_for_timeout(800)
        except Exception:
            pass
        entry['quiz_still_open'] = dialog_visible(page)
    return True


def save(path, payload):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    for attempt in range(3):
        try:
            temp.replace(path)
            return
        except PermissionError:
            if attempt == 2:
                raise
            time.sleep(0.2)


def catalog_from(payload):
    """把 videolist 响应展开成可播放单元列表。"""
    data = (payload or {}).get('data') or {}
    units = []
    for chapter in data.get('videoChapterDtos') or []:
        for lesson in chapter.get('videoLessons') or []:
            smalls = lesson.get('videoSmallLessons') or []
            for item in (smalls if smalls else [lesson]):
                units.append({
                    'chapter': chapter.get('name'),
                    'chapterId': chapter.get('id'),
                    'lessonId': lesson.get('id'),
                    'id': item.get('id'),
                    'name': item.get('name'),
                    'videoId': item.get('videoId'),
                    'videoSec': item.get('videoSec'),
                })
    return units


def progress_from(payload):
    """queryStuyInfo -> {unitId: {'studyTotalTime': int, 'watchState': int}}"""
    data = (payload or {}).get('data') or {}
    merged = {}
    for group in ('lesson', 'lv'):
        for key, value in (data.get(group) or {}).items():
            if isinstance(value, dict):
                merged[str(key)] = value
    return merged


def parse_urls(values):
    """把多个 --url 拆成去重后的网址列表（支持换行、逗号、空格分隔）。"""
    urls = []
    seen = set()
    for raw in values:
        for line in re.split(r'[\r\n,，\s]+', str(raw)):
            url = line.strip()
            if url and url not in seen:
                seen.add(url)
                urls.append(url)
    return urls


def main():
    parser = argparse.ArgumentParser(description='共享课学习引擎（驱动页面自己上报）')
    parser.add_argument('--url', action='append', default=[],
                        help='共享课页面网址，可重复；一次给多门会依次处理')
    parser.add_argument('--channel', choices=('msedge', 'chrome', 'chromium'), default='msedge')
    parser.add_argument('--limit', type=int, default=0, help='每门课只处理前 N 节（0=全部）')
    parser.add_argument('--rate', type=float, default=1.5,
                        help='播放倍速上限，官方上限 2；实际会在 1.2~该值之间浮动')
    parser.add_argument('--wait', type=int, default=45, help='每门课首屏等待秒数，默认 45')
    parser.add_argument('--tail', type=int, default=3, help='距结尾多少秒算播完')
    parser.add_argument('--poll', type=int, default=5, help='轮询间隔秒数')
    parser.add_argument('--check-every', type=int, default=15,
                        help='每隔多少秒检查一次本节进度，默认 15')
    parser.add_argument('--max-replays', type=int, default=2,
                        help='播完但服务端没满足时长时，最多重播几遍补时长，默认 2')
    parser.add_argument('--max-units', type=int, default=0,
                        help='单次最多刷几节就收工（0=不限），用于分段降低连续时长')
    parser.add_argument('--quiz-auto', dest='quiz_auto', action='store_true', default=True,
                        help='遇到弹题时按服务端答案自动作答（默认开启）')
    parser.add_argument('--no-quiz-auto', dest='quiz_auto', action='store_false',
                        help='遇到弹题就停下等你处理')
    parser.add_argument('--no-stealth', dest='stealth', action='store_false', default=True,
                        help='不抹掉浏览器的自动化标记（默认会抹掉）')
    parser.add_argument('--seed', type=int, default=0,
                        help='随机种子（0=每次不同），调试时可固定')
    args = parser.parse_args()

    if not 1.0 <= args.rate <= 2.0:
        parser.error('喵?！(>﹏<) --rate 只能是 1 到 2（平台官方倍速上限）')

    RNG.seed(args.seed or None)

    urls = parse_urls(args.url)
    if not urls:
        print('喵?！(>﹏<) 还差共享课页面网址喵～\n'
              f'  形如：{URL_HINT}\n'
              '  在界面里点“刷共享课”时填一次，程序会记住喵。')
        return 2
    bad = [url for url in urls if SHARED_HOST not in url]
    if bad:
        print(f'喵…(ಥ_ಥ) 这些网址不是共享课页面（需要 {SHARED_HOST} 开头）：')
        for url in bad:
            print('   ', url[:120])
        return 2

    OUTPUT.mkdir(parents=True, exist_ok=True)
    report_path = OUTPUT / (datetime.now().strftime('shared-learn-%Y%m%d-%H%M%S') + '.json')
    report = {'started_at': datetime.now().isoformat(), 'rate': args.rate,
              'courses': [], 'finished': False}

    state = {'catalog': None, 'progress': {}, 'quiz': None, 'last_quiz': 0, 'name': ''}

    # 弹题优先用服务端线索；线索不足时交给 DeepSeek 判断（需要 API Key）。
    ai_client = None
    try:
        import ai
        config = ai.load_config()
        key = (config.get('deepseek_api_key') or '').strip()
        if key:
            ai_client = ai.DeepSeek(key, config.get('base_url', ai.DEFAULT_BASE),
                                    config.get('model', ai.DEFAULT_MODEL))
            print('喵～弹题会用 DeepSeek 判断（已读到 API Key）', flush=True)
        else:
            print('喵(๑°3°๑) 没配 DeepSeek Key，弹题只靠服务端线索，可能停在弹题上', flush=True)
    except Exception as error:
        print(f'喵…AI 没启用（{type(error).__name__}），弹题只靠服务端线索', flush=True)

    from playwright.sync_api import sync_playwright

    def on_response(response):
        url = response.url
        try:
            if 'learning/videolist' in url:
                state['catalog'] = catalog_from(json.loads(response.text()))
            elif 'learning/queryStuyInfo' in url:
                state['progress'].update(progress_from(json.loads(response.text())))
            elif 'popupAnswer/lessonPopupExam' in url:
                state['quiz'] = json.loads(response.text())
                state['last_quiz'] = time.time()
        except Exception:
            pass

    print('喵(๑°3°๑) 打开共享课页面，本喵会让页面自己学，不伪造任何请求喵～', flush=True)
    with sync_playwright() as playwright:
        options = {'headless': False, 'service_workers': 'block',
                   'viewport': {'width': 1600, 'height': 900},
                   'locale': 'zh-CN', 'timezone_id': 'Asia/Shanghai',
                   # 允许自动播放，否则 programmatic play() 会被浏览器拒绝
                   'args': ['--autoplay-policy=no-user-gesture-required']}
        if args.channel != 'chromium':
            options['channel'] = args.channel
        if args.stealth:
            # Playwright 默认会带 --enable-automation，这个开关一开就露馅
            options['ignore_default_args'] = ['--enable-automation']
            options['args'].append('--disable-blink-features=AutomationControlled')
        try:
            context = playwright.chromium.launch_persistent_context(str(PROFILE), **options)
        except Exception as error:
            print(f'喵…(ಥ_ಥ) 浏览器没打开：{type(error).__name__}，请先关掉其它脚本窗口')
            return 2

        try:
            if args.stealth:
                context.add_init_script(STEALTH_JS)
                print('喵～已抹掉浏览器的自动化标记', flush=True)
            context.on('response', on_response)
            page = context.pages[0] if context.pages else context.new_page()
            def run_one(course_url, course):
                """处理一门课。每门课都要重置状态，免得上一门的数据串进来。"""
                state['catalog'] = None
                state['progress'] = {}
                state['quiz'] = None
                state['name'] = ''

                page.goto(course_url, wait_until='domcontentloaded', timeout=60000)
                print(f'喵～等页面加载（{args.wait} 秒）…', flush=True)
                page.wait_for_timeout(args.wait * 1000)

                course['name'] = state['name'] or course_url
                print(f"喵(●—●) 课程：{course['name']}", flush=True)

                units = state['catalog'] or []
                if not units:
                    # 多门课连跑时上一门刚切走，页面可能还没缓过来，刷新再等一次
                    print('喵…这次没读到目录，刷新页面再等一遍喵～', flush=True)
                    state['catalog'] = None
                    state['progress'] = {}
                    try:
                        page.reload(wait_until='domcontentloaded', timeout=60000)
                    except Exception:
                        page.goto(course_url, wait_until='domcontentloaded', timeout=60000)
                    page.wait_for_timeout(args.wait * 1000)
                    units = state['catalog'] or []
                if not units:
                    course['result'] = 'no_catalog'
                    print('喵…(ಥ_ಥ) 还是没读到课程目录，可以先加大 --wait 再试喵～')
                    return
                print(f'喵(●—●) 目录：{len(units)} 个视频单元', flush=True)

                dom = page.evaluate(UNITS_JS)
                print(f'喵～页面上找到 {len(dom)} 个可点击单元', flush=True)
                if not dom:
                    course['result'] = 'no_dom'
                    print('喵…(ಥ_ಥ) 页面上没找到 .video 单元，页面结构可能变了')
                    return

                # 校验目录顺序与 DOM 顺序一致（防止点错节）
                mismatches = 0
                for index in range(min(len(units), len(dom))):
                    name = (units[index].get('name') or '').strip()
                    text = (dom[index]['full'] or '').replace(' ', '')
                    if name and name.replace(' ', '') not in text:
                        mismatches += 1
                print(f'喵～顺序校验：{min(len(units), len(dom)) - mismatches}/'
                      f'{min(len(units), len(dom))} 对得上', flush=True)
                if mismatches > max(3, len(dom) // 4):
                    course['result'] = 'layout_mismatch'
                    print('喵…(ಥ_ಥ) 目录和页面顺序差太多，为了不点错节先停下这门课', flush=True)
                    return

                course['total'] = len(units)
                # 把判定依据摊开：watchState 可能是数字也可能是字符串，
                # 只按一种比会整片误判，所以统一转字符串比较。
                snapshot = []
                stats = {'1': 0, '2': 0, '0': 0, 'missing': 0}
                for index, unit in enumerate(units):
                    entry_state = state['progress'].get(str(unit['id'])) or {}
                    raw = entry_state.get('watchState')
                    key = 'missing' if raw is None else str(raw).strip()
                    stats[key if key in stats else 'x'] = stats.get(key if key in stats else 'x', 0) + 1
                    snapshot.append({'id': unit['id'], 'name': unit.get('name'),
                                     'videoSec': unit.get('videoSec'),
                                     'watchState': raw,
                                     'studyTotalTime': entry_state.get('studyTotalTime')})
                course['progress_stats'] = stats
                course['progress_snapshot'] = snapshot

                print(f"喵(●—●) 服务端状态：完成 {stats['1']}、学习中 {stats['2']}、"
                      f"未开始 {stats['0']}、无记录 {stats['missing']}", flush=True)

                # 标记完成但时长明显不足的，单独列出来（多半是判定口径问题）
                odd = [d for d in snapshot if str(d['watchState']) == '1'
                       and (d['studyTotalTime'] or 0) < (d['videoSec'] or 1) * 0.5]
                if odd:
                    print(f'喵…有 {len(odd)} 节被标成完成但时长不足一半，先按未完成处理：', flush=True)
                    for d in odd[:6]:
                        print(f"    {str(d['name'])[:18]:20s} {d['studyTotalTime']}/{d['videoSec']} 秒", flush=True)

                todo = []
                for index, unit in enumerate(units):
                    entry_state = state['progress'].get(str(unit['id'])) or {}
                    if needs_study(entry_state, unit.get('videoSec')):
                        todo.append((index, unit))
                    else:
                        course.setdefault('skipped_done', []).append({
                            'id': unit['id'], 'name': unit.get('name'),
                            'studyTotalTime': entry_state.get('studyTotalTime'),
                            'videoSec': unit.get('videoSec')})
                print(f'喵～未完成 {len(todo)} 节，已完成 {len(units) - len(todo)} 节', flush=True)
                course['pending_total'] = len(todo)
                if args.limit:
                    todo = todo[:args.limit]
                    print(f'喵～这门课只跑前 {len(todo)} 节（--limit {args.limit}）', flush=True)
                course['pending'] = len(todo)
                if args.max_units and len(todo) > args.max_units:
                    todo = todo[:args.max_units]
                    print(f'喵～这次只跑 {len(todo)} 节就收工（--max-units {args.max_units}），'
                          f'过一会儿再跑剩下的喵～', flush=True)
                if not args.stealth:
                    print('喵(๑°3°๑) 已关闭伪装（--no-stealth），平台更容易看出是脚本喵', flush=True)

                for index, unit in todo:
                    entry = {'index': index, 'id': unit['id'], 'name': unit['name'],
                             'lesson': unit.get('chapter'), 'videoSec': unit.get('videoSec'),
                             'result': 'pending'}
                    course['units'].append(entry)
                    save(report_path, report)

                    print(f"\n喵(•̀ᴗ•́)و 第 {index + 1}/{len(units)} 单元：{unit['name']}", flush=True)
                    # 上一节的弹题数据不能带到这一节
                    state['quiz'] = None
                    state['last_quiz'] = 0
                    # 走真实鼠标轨迹再点击，比 JS 直接 .click() 更接近真人操作
                    point = page.evaluate(UNIT_POINT_JS, index)
                    if not point:
                        entry['result'] = 'click_failed'
                        print('  喵…点不到这个单元，跳过', flush=True)
                        save(report_path, report)
                        continue
                    page.mouse.move(point['x'], point['y'], steps=RNG.randint(6, 18))
                    page.wait_for_timeout(RNG.randint(180, 650))
                    page.mouse.click(point['x'], point['y'])
                    page.wait_for_timeout(RNG.randint(2500, 5000))

                    # 每节自己挑一个倍速，避免整场恒定 2.0x 这种机械特征
                    rate = round(RNG.uniform(1.2, args.rate), 2)
                    entry['rate'] = rate
                    print(f'  喵～本节按 {rate}x 播放', flush=True)

                    started = time.time()
                    last_current = 0
                    last_log = started
                    last_check = started
                    stalled = 0
                    replays = 0
                    while True:
                        status = page.evaluate(STATE_JS)
                        if not status.get('ok'):
                            entry['result'] = 'no_video'
                            break
                        # 暂停就尝试播放。注意不能加 current > 0 的条件：
                        # 刚进课程时 current 还是 0，一加就永远不会开播。
                        if status.get('paused'):
                            entry['play_attempts'] = entry.get('play_attempts', 0) + 1
                            status = ensure_playing(page, rate) or status
                            if entry['play_attempts'] in (1, 5, 20):
                                print(f"  喵…第 {entry['play_attempts']} 次尝试播放，"
                                      f"当前 paused={status.get('paused')} "
                                      f"ready={status.get('ready')}", flush=True)
                        current, duration = status.get('current') or 0, status.get('duration') or 0

                        # 每 check_every 秒查一次本节进度：服务端状态或目录百分比满了就收工
                        if time.time() - last_check >= args.check_every:
                            last_check = time.time()
                            dom = page.evaluate(UNIT_PROGRESS_JS, index) or {}
                            server = state['progress'].get(str(unit['id'])) or {}
                            icon_class = str(dom.get('iconClass') or '').lower()
                            finished = (
                                watch_state(server.get('watchState')) == 1
                                or (dom.get('percent') is not None and dom['percent'] >= 100)
                                or 'finish' in icon_class
                                or 'complete' in icon_class
                            )
                            entry['last_check'] = {
                                'server': server.get('studyTotalTime'),
                                'watch': server.get('watchState'),
                                'dom': dom.get('percent'),
                            }
                            if finished:
                                entry['result'] = 'completed_early'
                                print(f"  喵～本节进度已满（服务端 {server}，"
                                      f"目录 {dom.get('percent')}%），进入下一节", flush=True)
                                break

                        if duration and current >= duration - args.tail:
                            # 播完了，但如果服务端时长没满足，就地重播补时长，
                            # 免得留到下次再跑一遍
                            server = state['progress'].get(str(unit['id'])) or {}
                            if watch_state(server.get('watchState')) == 1:
                                entry['result'] = 'played_to_end'
                                break
                            replays += 1
                            entry['replays'] = replays
                            if replays > args.max_replays:
                                entry['result'] = 'played_to_end'
                                print(f'  喵…已重播 {args.max_replays} 遍仍未满足时长，'
                                      f'先记 not_confirmed 喵～', flush=True)
                                break
                            print(f"  喵～这一遍播完了，但服务端还差"
                                  f"（{server.get('studyTotalTime')}/{unit.get('videoSec')} 秒），"
                                  f"重播第 {replays} 遍补时长", flush=True)
                            page.evaluate(REWIND_JS)
                            page.wait_for_timeout(1500)
                            page.evaluate(PLAY_JS, rate)
                            started = time.time()
                            last_current = 0
                            last_check = time.time()
                            stalled = 0
                            continue

                        # 每 30 秒报一次进度，免得看着像卡住
                        if time.time() - last_log >= 30:
                            last_log = time.time()
                            left = max(0, duration - current)
                            print(f'    喵…进度 {current:,.0f}/{duration:,.0f} 秒'
                                  f'（还剩 {left / max(rate, 0.5) / 60:.0f} 分钟）', flush=True)
                        if current <= last_current:
                            stalled += 1
                        else:
                            stalled = 0
                        last_current = current
                        if stalled >= 12:
                            entry['result'] = 'stalled'
                            break
                        if time.time() - started > (duration or 3600) / max(rate, 0.5) + 600:
                            entry['result'] = 'timeout'
                            break
                        # 只有收到 lessonPopupExam 且能解析出题目，才算「真弹题」。
                        # 页面上「温馨提示 / 我知道了」那种纯提示不能当题答。
                        quiz = quiz_ready(state)
                        if quiz:
                            entry['quiz'] = re.sub(r'<[^>]*>', '', quiz['question'])[:120]
                            print(f"  喵…遇到弹题：{entry['quiz'][:60]}", flush=True)
                            if not args.quiz_auto:
                                entry['result'] = 'quiz_paused'
                                break
                            think = RNG.randint(4000, 15000)
                            print(f'  喵～先想 {think / 1000:.0f} 秒再答', flush=True)
                            page.wait_for_timeout(think)
                            if not answer_one(page, quiz, entry, ai_client):
                                entry['result'] = 'quiz_unanswered'
                                break
                            state['quiz'] = None   # 用完清掉，免得反复答同一题
                            print('  喵～已作答，继续播放', flush=True)
                            page.wait_for_timeout(RNG.randint(1200, 2500))
                            page.evaluate(PLAY_JS, rate)
                            continue

                        # 「AI助教小智出题」这类弹题不走接口，只能从页面文字里读
                        dom_quiz = read_quiz_from_frames(page)
                        if dom_quiz:
                            entry['quiz'] = f"{dom_quiz.get('type', '')} " \
                                            f"{dom_quiz['question'][:60]}"
                            print(f"  喵…AI助教出题：{dom_quiz['question'][:50]}", flush=True)
                            if not args.quiz_auto:
                                entry['result'] = 'quiz_paused'
                                break
                            think = RNG.randint(5000, 16000)
                            print(f'  喵～先想 {think / 1000:.0f} 秒再答', flush=True)
                            page.wait_for_timeout(think)
                            if not answer_dom_quiz(page, dom_quiz, entry, ai_client):
                                # 答不了就关掉继续播，别把整节卡死
                                entry['quiz_error'] = entry.get('quiz_error', 'unanswered')
                                print('  喵…这题答不了，先关掉继续播', flush=True)
                                dismiss_any(page)
                                page.wait_for_timeout(RNG.randint(800, 1800))
                                page.evaluate(PLAY_JS, rate)
                                continue
                            print('  喵～已作答并关闭，继续播', flush=True)
                            page.wait_for_timeout(RNG.randint(1500, 3500))
                            page.evaluate(PLAY_JS, rate)
                            continue

                        # 纯提示框：点掉它，然后恢复播放，别中断这一节
                        prompt = eval_every_frame(page, PROMPT_JS)
                        if prompt:
                            dismissed = dismiss_any(page)
                            if dismissed and entry.get('prompts', 0) < 40:
                                entry['prompts'] = entry.get('prompts', 0) + 1
                                print(f"  喵～关掉提示框（{dismissed['label']}），继续播", flush=True)
                                page.wait_for_timeout(RNG.randint(800, 2000))
                                page.evaluate(PLAY_JS, rate)
                                # 关掉后视频常被暂停，等一拍再确认一次
                                page.wait_for_timeout(600)
                                page.evaluate(PLAY_JS, rate)
                                continue
                            entry['prompt_text'] = prompt[0]['text'][:200]
                            entry['prompt_html'] = prompt[0].get('html', '')[:400]
                            print(f"  喵…有个关不掉的框：{prompt[0]['text'][:50]}", flush=True)
                        page.wait_for_timeout(args.poll * 1000)

                    entry['elapsed'] = round(time.time() - started, 1)
                    entry['final_state'] = state['progress'].get(str(unit['id']))
                    done = watch_state((entry['final_state'] or {}).get('watchState')) == 1
                    if done:
                        entry['result'] = 'completed'
                    elif entry.get('result') == 'completed_early':
                        pass          # 目录显示已满，保留这个结论
                    else:
                        entry['result'] = entry.get('result', 'not_confirmed')
                    print(f"  喵～{entry['result']}（{entry['elapsed']}s，"
                          f"服务端 {entry['final_state']}）", flush=True)
                    save(report_path, report)
                    # 节与节之间歇一下，避免机械的固定节奏
                    page.wait_for_timeout(RNG.randint(1500, 6000))

                course['completed'] = sum(1 for u in course['units']
                                          if u.get('result') in ('completed', 'completed_early'))
                course['result'] = 'done'

            for position, course_url in enumerate(urls, 1):
                if args.limit and position > 1:
                    print('\n喵～试跑模式只动第一门课，剩下的等验证通过再来喵～', flush=True)
                    break
                course = {'url': course_url, 'position': position, 'name': '',
                          'units': [], 'result': 'pending'}
                report['courses'].append(course)
                save(report_path, report)
                print(f"\n{'=' * 62}\n喵(๑＞ڡ＜)☆ 第 {position}/{len(urls)} 门共享课\n{'=' * 62}",
                      flush=True)
                try:
                    run_one(course_url, course)
                except Exception as error:
                    name = type(error).__name__
                    course['result'] = f'error: {name}'
                    print(f'喵…(ಥ_ಥ) 这门课出错了：{name}：{error}', flush=True)
                    if name in {'TargetClosedError', 'BrowserClosedError'}:
                        print('喵…浏览器窗口被关掉了，剩下的课没法继续了喵～', flush=True)
                        report['aborted'] = 'browser_closed'
                        save(report_path, report)
                        break
                save(report_path, report)

            report['finished'] = True
            save(report_path, report)
            handled = sum(len(c['units']) for c in report['courses'])
            completed = sum(1 for c in report['courses'] for u in c['units']
                            if u.get('result') == 'completed')
            print(f'\n喵(●—●) 共 {len(report["courses"])} 门课、处理 {handled} 个单元，'
                  f'服务端确认完成 {completed} 个。\n报告：{report_path}', flush=True)
        finally:
            context.close()
    return 0


if __name__ == '__main__':
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, 'reconfigure'):
            stream.reconfigure(encoding='utf-8', errors='replace')
    sys.exit(main())
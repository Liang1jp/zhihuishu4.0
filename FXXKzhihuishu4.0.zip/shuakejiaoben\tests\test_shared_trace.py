"""Verify shared_trace's filtering and saving without launching a browser."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'script'))
import shared_trace  # noqa: E402


class FakeRequest:
    def __init__(self, method, post_data=None):
        self.method = method
        self.post_data = post_data


class FakeResponse:
    def __init__(self, url, body, status=200, method='POST', post_data=None):
        self.url = url
        self.status = status
        self.request = FakeRequest(method, post_data)
        self._body = body

    def text(self):
        return self._body


class FakeContext:
    def __init__(self):
        self.handlers = []

    def on(self, event, callback):
        self.handlers.append((event, callback))

    def fire(self, response):
        for event, callback in self.handlers:
            if event == 'response':
                callback(response)


def main():
    # Path extraction used in the trace output.
    assert shared_trace.strip_path(
        'https://studyservice-api.zhihuishu.com/gateway/t/v1/learning/videolist?x=1'
    ) == 'learning/videolist'
    print('strip_path: OK')

    context = FakeContext()
    records = []
    shared_trace.attach(context, records)

    context.fire(FakeResponse(
        'https://studyservice-api.zhihuishu.com/gateway/t/v1/learning/videolist',
        '{"code":0,"data":{"videoChapterDtos":[]}}',
        post_data='{"recruitId":"1001","courseId":"2002"}'))
    context.fire(FakeResponse('https://studyvideoh5.zhihuishu.com/image.png', 'PNG'))
    context.fire(FakeResponse(
        'https://studyservice-api.zhihuishu.com/gateway/t/v1/learning/saveDatabaseIntervalTimeV2',
        '{"code":0}', post_data='{"recruitId":"1001"}'))

    assert len(records) == 2, f'expected 2 api records, got {len(records)}'
    assert records[0]['path'] == 'learning/videolist'
    assert records[0]['post_data'] == '{"recruitId":"1001","courseId":"2002"}'
    assert records[1]['path'] == 'learning/saveDatabaseIntervalTimeV2'
    print('filter + payload capture: OK')

    folder = Path(__file__).resolve().parent / '.tmp-trace'
    folder.mkdir(exist_ok=True)
    try:
        target = folder / 'trace.json'
        shared_trace.save(target, {'records': records})
        loaded = json.loads(target.read_text(encoding='utf-8'))
        assert len(loaded['records']) == 2
        assert not target.with_suffix('.tmp').exists(), 'temp file must be cleaned up'
    finally:
        for leftover in folder.glob('*'):
            leftover.unlink(missing_ok=True)
        folder.rmdir()
    print('save: OK')
    print('\nOK: shared_trace behaves as intended')


if __name__ == '__main__':
    main()
"""检查 shared_learn.py 里内嵌 JS 的语法是否合法。

Python 侧只能保证字符串没写错，JS 真能 parse 还得靠 Node 验一遍。
"""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'script'))
import shared_learn  # noqa: E402

NODE_CANDIDATES = [
    Path.home() / '.dsh/dsh-runtimes/dsh-primary-runtime/dependencies/node/bin/node.exe',
]

JS_NAMES = ['STEALTH_JS', 'UNIT_POINT_JS', 'UNIT_PROGRESS_JS', 'REWIND_JS', 'PLAY_JS',
            'CLICK_PLAY_JS', 'STATE_JS', 'PROMPT_JS', 'DISMISS_JS', 'QUIZ_DOM_JS',
            'OPTION_POINT_JS', 'PLAYTOPIC_POINT_JS', 'PLAYTOPIC_TEXT_JS',
            'PROBE_DIALOG_JS', 'SUBMIT_JS']


def find_node():
    for path in NODE_CANDIDATES:
        if path.exists():
            return str(path)
    return 'node'


def main():
    node = find_node()
    # 分发给别人时不一定装了 Node，那就跳过这项检查
    try:
        probe = subprocess.run([node, '--version'], capture_output=True, text=True, timeout=10)
        if probe.returncode != 0:
            raise FileNotFoundError
    except (FileNotFoundError, OSError):
        print('未找到 node，跳过内嵌 JS 语法检查（不影响使用）')
        return 0

    failures = []
    for name in JS_NAMES:
        source = getattr(shared_learn, name, None)
        if source is None:
            print(f'  {name}: 缺失')
            failures.append(name)
            continue
        import json
        # 有的是表达式（箭头函数 / IIFE），有的是语句序列，两种都试
        checker = ("const src = " + json.dumps(source) + ";\n"
                   "const tries = [\n"
                   "  () => new Function('return (' + src + ')'),\n"
                   "  () => new Function(src),\n"
                   "];\n"
                   "let last = null;\n"
                   "for (const attempt of tries) {\n"
                   "  try { attempt(); process.exit(0); } catch (e) { last = e; }\n"
                   "}\n"
                   "console.error(last && last.message);\n"
                   "process.exit(1);")
        result = subprocess.run([node, '-e', checker], capture_output=True, text=True)
        ok = result.returncode == 0
        print(f'  {name:18s} {"OK" if ok else "语法错误: " + result.stderr.strip()[:120]}')
        if not ok:
            failures.append(name)
    if failures:
        print(f'\n有问题的 JS：{failures}')
        return 1
    print(f'\nOK: {len(JS_NAMES)} 段内嵌 JS 语法都合法')
    return 0


if __name__ == '__main__':
    sys.exit(main())
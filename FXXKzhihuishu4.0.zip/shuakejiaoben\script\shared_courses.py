"""识别账号下的共享课清单。

打开老平台学生首页（onlinestuh5），从页面**自己发出的**接口响应里捞出
课程列表，再用平台自己的编码算法还原成可播放的 stuStudy 网址。

用法：
    python script\\shared_courses.py            # 识别并保存清单
    python script\\shared_courses.py --wait 60  # 首页加载慢就加时间

只读：只打开首页、读响应，不播放、不上报。
"""
import argparse
import json
import re
import sys
import time
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROFILE = ROOT / '.session'
OUTPUT = ROOT / 'output'
LIST_PAGE = 'https://onlineweb.zhihuishu.com/onlinestuh5'
STUDY_PAGE = 'https://studyvideoh5.zhihuishu.com/stuStudy'
ENCODE_KEY = 'zhihuishu'


def encode_course_id(recruit_id, course_id):
    """[recruitId, courseId] -> 网址里的 recruitAndCourseId。

    与平台前端 os.Z() 完全一致：拼接后逐字符 XOR，转十六进制（至少两位），
    再取每种字符 hex 的最后四位。
    """
    text = f'{recruit_id};{course_id}'
    out = ''
    for index, char in enumerate(text):
        code = ord(char) ^ ord(ENCODE_KEY[index % len(ENCODE_KEY)])
        hexed = format(code, 'x')
        if len(hexed) < 2:
            hexed = '0' + hexed
        out += hexed[-4:]
    return out


def harvest(value, found, depth=0):
    """递归找出所有「像课程」的对象。"""
    if depth > 8:
        return
    if isinstance(value, dict):
        course_id = value.get('courseId')
        name = value.get('courseName') or value.get('name')
        if course_id and name and str(course_id).isdigit() and len(str(name).strip()) >= 2:
            found.append({
                'courseId': str(course_id),
                'courseName': str(name).strip(),
                'recruitId': str(value.get('recruitId') or value.get('recruit_id') or ''),
                'classId': str(value.get('classId') or ''),
                'isShareCourse': value.get('isShareCourse'),
            })
        for item in value.values():
            harvest(item, found, depth + 1)
    elif isinstance(value, list):
        for item in value:
            harvest(item, found, depth + 1)


def dedupe(rows):
    """按 (courseId, recruitId) 去重；同一门课若有带 recruitId 的版本，丢掉空的那条。

    同一 courseId 在不同学期会对应不同 recruitId，所以两者都保留；
    但「有 recruitId」和「没有 recruitId」的同课记录只留前者，否则拼不出网址。
    """
    exact = {}
    for row in rows:
        exact.setdefault((row['courseId'], row['recruitId']), row)
    with_recruit = {course_id for (course_id, recruit_id) in exact if recruit_id}
    return [row for (course_id, recruit_id), row in exact.items()
            if recruit_id or course_id not in with_recruit]


def save(path, payload):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    for attempt in range(3):
        try:
            temp.replace(path)
            return
        except PermissionError:
            if attempt == 2:
                raise
            time.sleep(0.2)


def main():
    parser = argparse.ArgumentParser(description='识别账号下的共享课清单')
    parser.add_argument('--channel', choices=('msedge', 'chrome', 'chromium'), default='msedge')
    parser.add_argument('--wait', type=int, default=45, help='首页加载等待秒数')
    args = parser.parse_args()

    OUTPUT.mkdir(parents=True, exist_ok=True)
    target = OUTPUT / (datetime.now().strftime('shared-courses-%Y%m%d-%H%M%S') + '.json')

    from playwright.sync_api import sync_playwright

    responses = []
    links = []

    def on_response(response):
        url = response.url
        if 'zhihuishu' not in url:
            return
        try:
            text = response.text()
        except Exception:
            return
        if 'courseName' not in text and 'courseId' not in text:
            return
        try:
            responses.append({'url': url, 'data': json.loads(text)})
        except Exception:
            pass

    print('喵(๑°3°๑) 打开学生首页，看看这个账号有哪些共享课喵～', flush=True)
    with sync_playwright() as playwright:
        options = {'headless': False, 'service_workers': 'block',
                   'viewport': {'width': 1600, 'height': 900},
                   'locale': 'zh-CN', 'timezone_id': 'Asia/Shanghai',
                   'ignore_default_args': ['--enable-automation'],
                   'args': ['--disable-blink-features=AutomationControlled']}
        if args.channel != 'chromium':
            options['channel'] = args.channel
        try:
            context = playwright.chromium.launch_persistent_context(str(PROFILE), **options)
            context.add_init_script(
                "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});"
                "if (!window.chrome) { window.chrome = {runtime: {}}; }")
        except Exception as error:
            print(f'喵…(ಥ_ಥ) 浏览器没打开：{type(error).__name__}，请先关掉其它脚本窗口')
            return 2

        try:
            context.on('response', on_response)
            page = context.pages[0] if context.pages else context.new_page()
            page.goto(LIST_PAGE, wait_until='domcontentloaded', timeout=90000)
            print(f'喵～等首页加载（{args.wait} 秒）…', flush=True)
            page.wait_for_timeout(args.wait * 1000)

            # 页面里的链接也可能直接带着课程编号
            try:
                links = page.evaluate("""() => [...document.querySelectorAll('a[href]')]
                    .map(a => ({href: a.href, text: (a.textContent || '').trim().slice(0, 60)}))
                    .filter(x => /recruitId|courseId|stuStudy|recruitAndCourseId/i.test(x.href))""")
            except Exception:
                links = []

            found = []
            for item in responses:
                harvest(item['data'], found)
            courses = dedupe(found)

            for course in courses:
                if course['recruitId']:
                    token = encode_course_id(course['recruitId'], course['courseId'])
                    course['url'] = f"{STUDY_PAGE}?recruitAndCourseId={token}"
                else:
                    course['url'] = ''

            result = {'started_at': datetime.now().isoformat(), 'page': LIST_PAGE,
                      'courses': courses, 'links': links,
                      'response_urls': [item['url'] for item in responses]}
            save(target, result)

            print(f'\n喵(●—●) 找到 {len(courses)} 门课程：', flush=True)
            for index, course in enumerate(courses, 1):
                share = '共享课' if course.get('isShareCourse') == 1 else '未知类型'
                print(f"  {index:2d}. {course['courseName'][:34]:36s} "
                      f"courseId={course['courseId']:<12} recruitId={course['recruitId'] or '?':<10} {share}")
                if course['url']:
                    print(f"      {course['url']}")
                else:
                    print('      （缺 recruitId，暂时拼不出网址）')

            if links:
                print(f'\n喵～页面链接 {len(links)} 条（前 8）：', flush=True)
                for link in links[:8]:
                    print(f"  {link['text'][:24]:26s} {link['href'][:110]}")

            if not courses:
                print('\n喵…(ಥ_ಥ) 没从接口响应里认出课程。可能要手动点一下「我的课程」，'
                      '或者把报告发给开发者看看。', flush=True)
                print(f'  捕获到的响应地址：{len(responses)} 条', flush=True)
                for item in responses[:10]:
                    print(f"    {item['url'][:120]}")
            print(f'\n清单已保存：{target}', flush=True)
        finally:
            context.close()
    return 0


if __name__ == '__main__':
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, 'reconfigure'):
            stream.reconfigure(encoding='utf-8', errors='replace')
    sys.exit(main())
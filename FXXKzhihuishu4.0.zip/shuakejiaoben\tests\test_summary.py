"""Verify the run-summary wording that reports recognized-but-unprocessed courses."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'script'))
import run  # noqa: E402


def main():
    courses = run.course_list({
        'studyCourseList': [
            {'courseId': 111, 'classId': 1, 'courseName': '高等数学',
             'courseType': 0, 'newFlag': True},
            {'courseId': 222, 'classId': 2, 'courseName': '共享通识课',
             'courseType': 2, 'newFlag': True},
        ],
        'completeCourseList': [],
    })
    skipped = [c for c in courses if c['kind'] != '智慧课程']
    supported = [c for c in courses if c['kind'] == '智慧课程']

    kinds = {}
    for course in skipped:
        kinds[course['kind']] = kinds.get(course['kind'], 0) + 1
    note = ('另外识别到但没有处理的课程：' +
            '、'.join(f'{kind} {count} 门' for kind, count in kinds.items()) + '。\n')
    summary = '识别到：' + '、'.join(
        f'{kind} {count} 门' for kind, count in run.course_breakdown(courses).items())
    print(note + summary)

    assert '共享课 1 门' in note, 'summary must name the skipped 共享课'
    assert [c['name'] for c in supported] == ['高等数学'], 'only 智慧课程 are processed'
    print('OK: summary names the skipped 共享课')


if __name__ == '__main__':
    main()
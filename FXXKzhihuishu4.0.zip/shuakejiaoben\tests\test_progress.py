"""Verify progress judgement: numeric vs string watchState, and fake completions."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'script'))
import shared_learn  # noqa: E402


def main():
    need = shared_learn.needs_study

    # 1) Missing / unstarted / studying -> must be studied.
    assert need(None, 600) is True
    assert need({}, 600) is True
    assert need({'watchState': 0, 'studyTotalTime': 0}, 600) is True
    assert need({'watchState': 2, 'studyTotalTime': 300}, 600) is True

    # 2) Real completion: watchState 1 and roughly full duration.
    assert need({'watchState': 1, 'studyTotalTime': 598}, 600) is False
    assert need({'watchState': '1', 'studyTotalTime': 598}, 600) is False
    assert need({'watchState': 1.0, 'studyTotalTime': 598}, 600) is False

    # 3) Fake completion: marked done but barely studied -> redo.
    assert need({'watchState': 1, 'studyTotalTime': 0}, 600) is True
    assert need({'watchState': '1', 'studyTotalTime': 120}, 600) is True

    # 4) Unknown duration must not make everything look unfinished.
    assert need({'watchState': 1, 'studyTotalTime': 0}, 0) is False

    # 5) Whitespace-padded strings still parse.
    assert need({'watchState': ' 1 ', 'studyTotalTime': 590}, 600) is False
    assert shared_learn.watch_state('1') == 1
    assert shared_learn.watch_state(1.0) == 1
    assert shared_learn.watch_state(None) is None
    assert shared_learn.watch_state('abc') is None

    print('needs_study: numeric / string / fake-completion all handled')

    # Sanity: a mixed snapshot should yield a believable todo count.
    units = [{'id': i, 'videoSec': 600} for i in range(1, 6)]
    progress = {
        '1': {'watchState': 1, 'studyTotalTime': 600},   # done
        '2': {'watchState': '1', 'studyTotalTime': 590}, # done (string)
        '3': {'watchState': 2, 'studyTotalTime': 200},   # studying
        '4': {'watchState': 1, 'studyTotalTime': 30},    # fake completion
        # '5' missing entirely
    }
    todo = [u for u in units if need(progress.get(str(u['id'])), u['videoSec'])]
    print('todo ids:', [u['id'] for u in todo])
    assert [u['id'] for u in todo] == [3, 4, 5], todo
    print('\nOK: progress judgement is sound')


if __name__ == '__main__':
    main()
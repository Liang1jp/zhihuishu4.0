"""Static scope check: module-level functions must not reference undefined globals.

Regression guard for the `rng` bug, where a module-level helper referenced a
local variable from main() and blew up with NameError mid-run.
"""
import builtins
import symtable
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / 'script'
BUILTINS = set(dir(builtins))


def undefined_globals(path):
    source = path.read_text(encoding='utf-8')
    module = symtable.symtable(source, str(path), 'exec')
    module_names = {symbol.get_name() for symbol in module.get_symbols()}
    problems = []

    def walk(table, prefix):
        for child in table.get_children():
            name = f'{prefix}.{child.get_name()}' if prefix else child.get_name()
            if child.get_type() in ('function', 'class'):
                for symbol in child.get_symbols():
                    if symbol.is_local() or symbol.is_parameter() or symbol.is_imported():
                        continue
                    symbol_name = symbol.get_name()
                    if (symbol.is_global() and symbol_name not in module_names
                            and symbol_name not in BUILTINS):
                        problems.append((name, symbol_name))
            walk(child, name)

    walk(module, '')
    return problems


def main():
    files = sorted(ROOT.glob('*.py'))
    assert files, '没有找到任何源文件'
    bad = 0
    for path in files:
        problems = undefined_globals(path)
        status = 'OK' if not problems else '有问题'
        print(f'{path.name:22s} {status}')
        for where, name in problems:
            print(f'    {where}: {name} 未定义')
            bad += 1
    assert bad == 0, f'{bad} 处未定义的全局引用'
    print(f'\nOK: {len(files)} 个文件的模块级作用域都干净')


if __name__ == '__main__':
    sys.exit(main())